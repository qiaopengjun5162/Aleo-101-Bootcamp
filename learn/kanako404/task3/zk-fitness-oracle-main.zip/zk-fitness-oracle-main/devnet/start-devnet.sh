#!/bin/bash
# Start 4 snarkOS dev validators in background, keep container alive
for i in 0 1 2 3; do
  /aleo/bin/snarkos start --dev $i --nodisplay --validator &
  sleep 2
done
# Wait for all background processes
wait
