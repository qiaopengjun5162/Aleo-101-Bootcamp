# ZK Fitness Oracle — 基于零知识证明的隐私健身应用

一个真正基于 **Leo Language** 和 **Aleo Network** 构建的隐私健身计算 dApp。用户的身体数据（身高、体重、出生年份、性别）作为**私有输入**进入零知识电路，计算结果可被验证但原始数据永远不会泄露。

## 功能特性

### 隐私计算
- **BMI（体质指数）** — 基于身高体重的健康指标
- **BMR（基础代谢率）** — Mifflin-St Jeor 公式整数近似
- **体脂率估算** — Deurenberg 公式整数近似
- **健康评分** — 基于 BMI 偏差的综合评分
- 所有计算在 Leo 零知识电路中完成，私有数据不离开本地

### 执行模式
| 模式 | 说明 |
|------|------|
| **ZK 模式** | 通过 `@provablehq/sdk` 在浏览器中运行 snarkVM WASM，生成真实的零知识证明 |
| **本地模式** | TypeScript 镜像 Leo 电路逻辑，当 WASM 不可用时自动降级 |

### 钱包支持
- **Leo Wallet** — 优先支持 Leo Wallet 浏览器插件连接
- **内置账户** — 可通过 SDK 生成新账户或导入私钥

### RPG 游戏化
- 基于计算结果生成个性化健身建议
- RPG 风格的任务系统（含 XP 奖励和难度分级）
- 赛博朋克视觉风格 UI

## 技术栈

| 技术 | 用途 |
|------|------|
| **Leo 4.x** | 零知识智能合约语言，编写隐私计算逻辑 |
| **Aleo / snarkVM** | ZK 证明系统（Groth16 + R1CS） |
| **@provablehq/sdk** | 浏览器端 Aleo SDK（WASM） |
| **React + TypeScript** | 前端框架 |
| **Vite** | 构建工具 |
| **Tailwind CSS** | 样式 |
| **Vitest** | 单元测试框架 |
| **Web Workers + Comlink** | 后台执行 ZK 证明，避免阻塞 UI |

## 项目结构

```
├── fitness_oracle/          # Leo 程序
│   ├── program.json         # 程序元信息
│   ├── src/main.leo         # Leo 源码（隐私计算逻辑）
│   └── build/               # 编译输出（Aleo 指令）
├── src/
│   ├── App.tsx              # 主应用组件
│   ├── leoRuntime.ts        # ZK 执行引擎 + 本地计算镜像
│   ├── aleo/program.ts      # Leo 程序接口（输入构建 + 输出解析）
│   ├── wallet/leoWallet.ts  # Leo Wallet 浏览器插件适配器
│   ├── workers/             # Web Worker（WASM 执行环境）
│   ├── components/          # UI 组件
│   └── __tests__/           # 单元测试
├── devnet/                  # 本地开发网络配置
├── LICENSE                  # CC BY-NC 4.0
└── README.md
```

## 快速开始

### 前置要求
- Node.js 18+
- Leo CLI 4.x（`cargo install leo-lang`）
- Docker（用于本地开发网络）
- Leo Wallet 浏览器插件（可选）

### 安装与运行

```bash
# 安装前端依赖
npm install

# 编译 Leo 程序
cd fitness_oracle && leo build && cd ..

# 启动开发服务器
npm run dev
```

### Leo 程序测试

```bash
# 编译
cd fitness_oracle && leo build

# 运行示例（正常男性：175cm, 70kg, 1995年出生）
leo run compute_fitness 175u32 70u32 1995u32 1u8 2026u32

# 更多测试用例
leo run compute_fitness 180u32 50u32 1998u32 1u8 2026u32   # 偏瘦
leo run compute_fitness 170u32 100u32 1990u32 1u8 2026u32  # 肥胖
leo run compute_fitness 165u32 55u32 2000u32 0u8 2026u32   # 正常女性
```

### 前端单元测试

```bash
npx vitest run
```

### 本地开发网络

```bash
# 启动 4 个 validator 节点的本地 Aleo 网络
docker run -d --name aleo-devnet -p 3030:3030 \
  -v ./devnet/start-devnet.sh:/start-devnet.sh \
  --entrypoint /bin/bash aleohq/snarkos:latest /start-devnet.sh

# 部署程序到本地网络
cd fitness_oracle
leo deploy --endpoint "http://localhost:3030" --network mainnet \
  --private-key "<DEV_PRIVATE_KEY>"
# 开发密钥可在 snarkOS 启动日志中找到，切勿在生产环境使用
```

## Leo 程序说明

`fitness_oracle.aleo` 接收 5 个输入：

| 参数 | 类型 | 可见性 | 说明 |
|------|------|--------|------|
| `height_cm` | `u32` | **private** | 身高（厘米） |
| `weight_kg` | `u32` | **private** | 体重（公斤） |
| `birth_year` | `u32` | **private** | 出生年份 |
| `gender` | `u8` | **private** | 性别（1=男, 0=女） |
| `current_year` | `u32` | **public** | 当前年份 |

输出 `FitnessData` 结构体（**private**），包含 BMI、BMR、体脂率、体型分类、健康评分和年龄。

> **ZK 电路注意事项**：零知识电路中三元运算的两个分支都会被执行，因此所有减法运算均通过"安全选择"模式实现，保证不会发生整数下溢。

## 许可证

本项目采用 [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/) 许可证。

- **需要声明引用来源**
- **禁止商业使用**
