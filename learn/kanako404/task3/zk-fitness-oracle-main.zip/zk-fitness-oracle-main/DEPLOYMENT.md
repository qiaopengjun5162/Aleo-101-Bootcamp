# 部署指南 — ZK Fitness Oracle

本文档说明如何在**本地测试网**和**Aleo 公共测试网**上部署 `fitness_oracle.aleo` 程序。

---

## 前置要求

| 工具 | 安装方式 | 验证命令 |
|------|----------|----------|
| **Leo CLI 4.x** | `cargo install leo-lang` | `leo --version` |
| **Docker** | [Docker Desktop](https://www.docker.com/products/docker-desktop/) | `docker --version` |
| **Node.js 18+** | [nodejs.org](https://nodejs.org/) | `node --version` |

---

## 一、编译 Leo 程序

```bash
cd fitness_oracle
leo build
```

成功输出：

```
Leo ✅ Compiled 'fitness_oracle.aleo' into Aleo instructions.
Leo ✅ Generated ABI for program 'fitness_oracle.aleo'.
```

编译产物位于 `fitness_oracle/build/fitness_oracle/fitness_oracle.aleo`。

### 验证程序逻辑

使用 `leo run` 在本地 VM 中测试（不需要网络）：

```bash
# 正常男性：175cm, 70kg, 1995年出生, 男(1), 当前2026年
leo run compute_fitness 175u32 70u32 1995u32 1u8 2026u32

# 预期输出：
# bmi_x100: 2285u32, bmr: 1600u32, fitness_class: 1u8, health_score: 99u8

# 更多测试用例
leo run compute_fitness 180u32 50u32 1998u32 1u8 2026u32   # 偏瘦
leo run compute_fitness 170u32 100u32 1990u32 1u8 2026u32  # 肥胖
leo run compute_fitness 165u32 55u32 2000u32 0u8 2026u32   # 正常女性
```

---

## 二、本地测试网部署

### 步骤 1：启动 4 节点 Devnet

Aleo 的 `--dev` 模式需要 4 个 validator 达成 BFT 共识。使用一个 Docker 容器内启动全部 4 个节点：

```bash
# 在项目根目录执行
docker run -d \
  --name aleo-devnet \
  -p 3030:3030 \
  -v ./devnet/start-devnet.sh:/start-devnet.sh \
  --entrypoint /bin/bash \
  aleohq/snarkos:latest \
  /start-devnet.sh
```

> `devnet/start-devnet.sh` 会依次启动 `--dev 0` 到 `--dev 3` 四个 validator。

### 步骤 2：等待出块

```bash
# 查看日志，确认出现 "Advanced to block" 字样
docker logs -f aleo-devnet 2>&1 | grep "Advanced"
```

通常 30-60 秒后开始出块。看到类似输出即可：

```
Advanced to block 10 at round 20 - ab1xxx...
```

### 步骤 3：部署程序

```bash
cd fitness_oracle

leo deploy \
  --endpoint "http://localhost:3030" \
  --network mainnet \
  --private-key "<DEV_PRIVATE_KEY>" \
  --yes \
  --broadcast
```

> **⚠️ 密钥说明**：
> - `<DEV_PRIVATE_KEY>` 替换为 snarkOS `--dev 0` 内置的开发密钥
> - 该密钥可在 snarkOS 启动日志中找到，仅用于本地开发，**切勿在生产环境使用**
> - `--network mainnet`：snarkOS devnet 默认以 mainnet 模式运行
> - `--private-key`：使用 `--dev 0` 内置的开发密钥（含有预分配资金）
> - `--yes`：跳过交互确认
> - `--broadcast`：将交易广播到网络
> - 部署过程需要生成 ZK 证明，可能需要 **2-5 分钟**

成功输出：

```
✅ Deployed 'fitness_oracle.aleo' to the network.
Transaction ID: at1xxx...
```

### 步骤 4：验证部署

```bash
# 通过 REST API 查询已部署的程序
curl http://localhost:3030/mainnet/program/fitness_oracle.aleo
```

### 管理 Devnet

```bash
# 查看日志
docker logs -f aleo-devnet

# 停止网络
docker stop aleo-devnet

# 重启网络（数据会保留）
docker start aleo-devnet

# 完全重置（清除所有数据）
docker rm -f aleo-devnet
# 然后重新执行步骤 1
```

---

## 三、公共测试网部署

### 步骤 1：获取测试网账户和资金

1. 安装 [Leo Wallet](https://www.leo.app/) 浏览器插件
2. 创建新钱包，切换到 **Testnet** 网络
3. 前往 [Aleo Faucet](https://faucet.aleo.org/) 领取测试币
4. 导出你的私钥（在 Leo Wallet 设置中）

### 步骤 2：部署到公共测试网

```bash
cd fitness_oracle

leo deploy \
  --endpoint "https://api.explorer.provable.com/v1" \
  --network testnet \
  --private-key "<你的私钥>" \
  --yes \
  --broadcast
```

> **注意**：
> - 公共测试网部署需要账户中有足够的测试币支付 gas
> - 部署费用约 1-5 credits（取决于程序大小）
> - 网络可能需要等待几个区块确认

### 步骤 3：验证部署

```bash
# 查询程序是否已上链
curl "https://api.explorer.provable.com/v1/testnet/program/fitness_oracle.aleo"
```

或访问 [Aleo Explorer](https://explorer.provable.com/) 搜索 `fitness_oracle.aleo`。

### 步骤 4：在链上执行

```bash
cd fitness_oracle

leo execute compute_fitness \
  175u32 70u32 1995u32 1u8 2026u32 \
  --endpoint "https://api.explorer.provable.com/v1" \
  --network testnet \
  --private-key "<你的私钥>" \
  --broadcast
```

---

## 四、前端连接已部署的程序

前端默认通过 `@provablehq/sdk` 在浏览器内本地执行 Leo 程序（不需要链上部署）。如果要连接已部署的链上程序：

1. 在前端配置中设置网络端点：

```typescript
// src/aleo/program.ts
export const NETWORK_ENDPOINT = "https://api.explorer.provable.com/v1";
// 本地开发网络使用：
// export const NETWORK_ENDPOINT = "http://localhost:3030";
```

2. 安装并连接 Leo Wallet 浏览器插件
3. 在应用首页点击"连接 Leo Wallet"

---

## 常见问题

### Q: `leo deploy` 提示余额不足？

```
Error: Insufficient balance to deploy the program.
```

- 本地网络：确保使用 `--dev 0` 对应的私钥（见 snarkOS 启动日志）
- 公共测试网：去 Faucet 领取更多测试币

### Q: Docker 容器启动后没有出块？

确认 4 个 validator 都已启动：

```bash
docker exec aleo-devnet ps aux | grep snarkos
```

应该看到 4 个 snarkos 进程。如果不够，重新创建容器。

### Q: `leo deploy` 超时？

部署需要生成 ZK 证明，可能需要几分钟。如果反复超时：

```bash
# 增加部署超时（如果 Leo CLI 支持）
# 或者先生成交易再手动广播
leo deploy --endpoint "http://localhost:3030" --network mainnet \
  --private-key "<DEV_PRIVATE_KEY>" --yes > deploy_tx.json

# 手动广播
curl -X POST "http://localhost:3030/mainnet/transaction/broadcast" \
  -H "Content-Type: application/json" \
  -d @deploy_tx.json
```

### Q: 程序名已被占用？

在公共测试网上，程序名必须唯一。修改 `fitness_oracle/program.json` 中的 `program` 字段：

```json
{
  "program": "fitness_oracle_v2.aleo"
}
```

然后同步更新 `src/main.leo` 中的 `program fitness_oracle_v2.aleo { ... }`。

---

## 五、测试环境清理

开发完成或暂停后，请及时清理测试环境以释放系统资源。

### 1. 停止前端开发服务器

在运行 `npm run dev` 的终端按 `Ctrl + C` 即可。

### 2. 停止并清理本地 Devnet

```bash
# 停止容器（保留数据，可随时 docker start 恢复）
docker stop aleo-devnet

# 彻底删除容器及其数据
docker rm -f aleo-devnet
```

### 3. 清理 Docker 镜像

snarkOS 镜像约 1-2 GB，不再需要时应清理：

```bash
# 查看镜像大小
docker images aleohq/snarkos

# 删除镜像
docker rmi aleohq/snarkos:latest

# 一次性清理所有未使用的镜像、容器、网络和构建缓存
docker system prune -a
```

> **⚠️ 注意**：`docker system prune -a` 会清理所有未使用的 Docker 资源，如果你有其他项目在用 Docker，请谨慎使用，建议改用上面的 `docker rmi` 单独删除。

### 4. 清理 Leo 编译缓存

```bash
# 删除编译产物
rm -rf fitness_oracle/build/
rm -rf fitness_oracle/outputs/

# 删除 Leo 全局缓存（可选，会影响其他 Leo 项目）
# Linux/macOS
rm -rf ~/.aleo/

# Windows
# 删除 %USERPROFILE%\.aleo\ 目录
```

### 5. 清理前端构建产物

```bash
# 删除打包输出
rm -rf dist/

# 删除依赖（可通过 npm install 重新安装）
rm -rf node_modules/
```

### 6. 资源占用参考

| 组件 | 运行时内存 | 磁盘占用 |
|------|-----------|---------|
| Docker snarkOS（4 节点） | ~2-4 GB | 镜像 ~1.5 GB + 链数据 |
| `npm run dev`（Vite） | ~200 MB | — |
| `leo build / run` | 峰值 ~500 MB | `build/` ~10 KB |
| `node_modules/` | — | ~300 MB |

> **建议**：不使用时至少执行 `docker stop aleo-devnet` 停止 Devnet，这是最大的资源消耗来源。
