import programSource from "../../fitness_oracle/build/fitness_oracle/fitness_oracle.aleo?raw";

export const PROGRAM_NAME = "fitness_oracle.aleo";
export const FUNCTION_NAME = "compute_fitness";
export const PROGRAM_SOURCE = programSource;

export function buildInputs(
  heightCm: number,
  weightKg: number,
  birthYear: number,
  gender: "male" | "female",
  currentYear: number,
): string[] {
  return [
    `${heightCm}u32`,
    `${weightKg}u32`,
    `${birthYear}u32`,
    gender === "male" ? "1u8" : "0u8",
    `${currentYear}u32`,
  ];
}

export interface ParsedFitnessData {
  bmi_x100: number;
  bmr: number;
  body_fat_x10: number;
  fitness_class: number;
  health_score: number;
  age: number;
}

export function parseOutputStruct(output: string): ParsedFitnessData {
  const extract = (key: string): number => {
    const re = new RegExp(`${key}:\\s*(\\d+)u\\d+`);
    const m = output.match(re);
    return m ? parseInt(m[1], 10) : 0;
  };
  return {
    bmi_x100: extract("bmi_x100"),
    bmr: extract("bmr"),
    body_fat_x10: extract("body_fat_x10"),
    fitness_class: extract("fitness_class"),
    health_score: extract("health_score"),
    age: extract("age"),
  };
}
