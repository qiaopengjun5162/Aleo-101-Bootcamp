import { wrap, type Remote } from "comlink";
import type { WorkerApi } from "./worker";

let singleton: Remote<WorkerApi> | null = null;

export function getAleoWorker(): Remote<WorkerApi> {
  if (!singleton) {
    const raw = new Worker(new URL("./worker.ts", import.meta.url), {
      type: "module",
    });
    raw.onerror = (e) => console.error("[AleoWorker]", e.message);
    singleton = wrap<WorkerApi>(raw);
  }
  return singleton;
}
