import { expose } from "comlink";

let Account: any;
let ProgramManager: any;
let AleoKeyProvider: any;
let initThreadPool: any;
let sdkReady = false;
let sdkError: string | null = null;

async function initSdk() {
  try {
    const sdk = await import("@provablehq/sdk");
    Account = sdk.Account;
    ProgramManager = sdk.ProgramManager;
    AleoKeyProvider = sdk.AleoKeyProvider;
    initThreadPool = sdk.initThreadPool;

    await initThreadPool();
    sdkReady = true;
  } catch (e: any) {
    sdkError = e?.message ?? String(e);
    console.warn("[AleoWorker] SDK init failed, falling back to local mode:", sdkError);
  }
}

const boot = initSdk();

async function isSdkReady(): Promise<{ ready: boolean; error: string | null }> {
  await boot;
  return { ready: sdkReady, error: sdkError };
}

async function generateAccount(): Promise<{
  privateKey: string;
  viewKey: string;
  address: string;
}> {
  await boot;
  if (!sdkReady) throw new Error("SDK not available");
  const account = new Account();
  return {
    privateKey: account.privateKey().to_string(),
    viewKey: account.viewKey().to_string(),
    address: account.address().to_string(),
  };
}

async function importAccount(privateKeyStr: string): Promise<{
  privateKey: string;
  viewKey: string;
  address: string;
}> {
  await boot;
  if (!sdkReady) throw new Error("SDK not available");
  const account = new Account({ privateKey: privateKeyStr });
  return {
    privateKey: account.privateKey().to_string(),
    viewKey: account.viewKey().to_string(),
    address: account.address().to_string(),
  };
}

async function executeProgram(
  program: string,
  functionName: string,
  inputs: string[],
  proveExecution: boolean,
): Promise<{ outputs: string[]; provingTimeMs: number }> {
  await boot;
  if (!sdkReady) throw new Error("SDK not available");

  const keyProvider = new AleoKeyProvider();
  keyProvider.useCache(true);

  const programManager = new ProgramManager(undefined, keyProvider);
  const account = new Account();
  programManager.setAccount(account);

  const start = performance.now();
  const response = await programManager.run(
    program,
    functionName,
    inputs,
    proveExecution,
  );
  const provingTimeMs = Math.round(performance.now() - start);
  const outputs = response.getOutputs();

  return { outputs, provingTimeMs };
}

const api = {
  isSdkReady,
  generateAccount,
  importAccount,
  executeProgram,
};

export type WorkerApi = typeof api;

expose(api);
