/// <reference types="vite/client" />

declare module "*.aleo?raw" {
  const content: string;
  export default content;
}
