import { getAleoWorker } from "./workers/AleoWorker";
import {
  PROGRAM_SOURCE,
  FUNCTION_NAME,
  buildInputs,
  parseOutputStruct,
  type ParsedFitnessData,
} from "./aleo/program";
import programSource from "../fitness_oracle/build/fitness_oracle/fitness_oracle.aleo?raw";

// ─── Public Types ──────────────────────────────────────────────────────────

export interface FitnessInput {
  heightCm: number;
  weightKg: number;
  birthYear: number;
  gender: "male" | "female";
}

export interface AleoAccount {
  privateKey: string;
  viewKey: string;
  address: string;
}

export interface FitnessProof {
  proofHash: string;
  executionMode: "zk" | "local";
  proofTime: number;
  programId: string;
  functionName: string;
  constraints: string;
}

export type BMICategory = "underweight" | "normal" | "overweight" | "obese";

export interface AdviceEntry {
  icon: string;
  title: string;
  body: string;
  type: "warning" | "success" | "info" | "danger";
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  difficulty: "E" | "D" | "C" | "B" | "A" | "S";
  completed: boolean;
  icon: string;
}

export interface FitnessResult {
  bmi: number;
  bmr: number;
  tdee: {
    sedentary: number;
    light: number;
    moderate: number;
    active: number;
    veryActive: number;
  };
  bodyFatEstimate: number;
  age: number;
  idealWeightRange: { min: number; max: number };
  bmiCategory: BMICategory;
  bmiDescription: string;
  healthScore: number;
  advice: AdviceEntry[];
  quests: Quest[];
  proof: FitnessProof;
  leoCode: string;
  rawOutputs: string[] | null;
}

// ─── SDK Status ────────────────────────────────────────────────────────────

let _sdkStatus: { ready: boolean; error: string | null } | null = null;

export async function checkSdkStatus(): Promise<{
  ready: boolean;
  error: string | null;
}> {
  if (_sdkStatus) return _sdkStatus;
  try {
    const worker = getAleoWorker();
    _sdkStatus = await worker.isSdkReady();
  } catch {
    _sdkStatus = { ready: false, error: "Worker failed to initialize" };
  }
  return _sdkStatus;
}

// ─── Account Management ───────────────────────────────────────────────────

export async function createAccount(): Promise<AleoAccount> {
  const worker = getAleoWorker();
  return worker.generateAccount();
}

export async function importAccount(
  privateKey: string,
): Promise<AleoAccount> {
  const worker = getAleoWorker();
  return worker.importAccount(privateKey);
}

// ─── Local Computation (mirrors the Leo circuit exactly) ──────────────────

function computeLocal(input: FitnessInput): ParsedFitnessData {
  const currentYear = new Date().getFullYear();
  const age = currentYear - input.birthYear;
  const h = input.heightCm;
  const w = input.weightKg;

  const bmi_x100 = Math.floor((w * 1_000_000) / (h * h));

  let fitness_class: number;
  if (bmi_x100 < 1850) fitness_class = 0;
  else if (bmi_x100 < 2500) fitness_class = 1;
  else if (bmi_x100 < 3000) fitness_class = 2;
  else fitness_class = 3;

  const bmr_base = 10 * w + 6 * h;
  const age_cost = 5 * age;
  const bmr_pos = bmr_base >= age_cost ? bmr_base - age_cost : 0;
  const bmr =
    input.gender === "male"
      ? bmr_pos + 5
      : bmr_pos >= 161
        ? bmr_pos - 161
        : 0;

  const bf_pos = Math.floor((120 * bmi_x100) / 100) + 23 * age;
  const bf_neg = input.gender === "male" ? 1620 : 540;
  const body_fat_x10 =
    bf_pos >= bf_neg ? Math.floor((bf_pos - bf_neg) / 10) : 0;

  const bmi_diff =
    bmi_x100 >= 2200 ? bmi_x100 - 2200 : 2200 - bmi_x100;
  const raw_penalty = Math.floor(bmi_diff / 50);
  const capped = raw_penalty >= 80 ? 80 : raw_penalty;
  const health_score = 100 - capped;

  return { bmi_x100, bmr, body_fat_x10, fitness_class, health_score, age };
}

// ─── High-Level Helpers ───────────────────────────────────────────────────

function categoryFromClass(c: number): BMICategory {
  return (["underweight", "normal", "overweight", "obese"] as const)[c] ?? "normal";
}

const CATEGORY_DESC: Record<BMICategory, string> = {
  underweight: "体重不足 / UNDERWEIGHT",
  normal: "健康体重 / NORMAL",
  overweight: "超重 / OVERWEIGHT",
  obese: "肥胖 / OBESE",
};

function buildAdvice(
  bmi: number,
  bmr: number,
  bodyFat: number,
  age: number,
  gender: "male" | "female",
): AdviceEntry[] {
  const advice: AdviceEntry[] = [];
  const cat = bmi < 18.5 ? "underweight" : bmi < 25 ? "normal" : bmi < 30 ? "overweight" : "obese";

  if (cat === "underweight") {
    advice.push({
      icon: "⚠️", title: "体重不足警告", type: "warning",
      body: `BMI ${bmi.toFixed(1)} 偏低。需增加优质蛋白质和复合碳水摄入，目标每周增重 0.3–0.5 kg。`,
    });
  } else if (cat === "normal") {
    advice.push({
      icon: "✅", title: "体重理想状态", type: "success",
      body: `BMI ${bmi.toFixed(1)} 处于健康区间！保持均衡饮食和每周 150 分钟中等强度有氧运动。`,
    });
  } else if (cat === "overweight") {
    advice.push({
      icon: "🔥", title: "超重警戒区域", type: "warning",
      body: `BMI ${bmi.toFixed(1)} 超出正常范围。建议每日制造 300–500 kcal 热量缺口，配合抗阻训练。`,
    });
  } else {
    advice.push({
      icon: "🚨", title: "肥胖风险等级 DANGER", type: "danger",
      body: `BMI ${bmi.toFixed(1)} 已达肥胖区间，心血管疾病和代谢综合征风险显著升高。强烈建议咨询医生。`,
    });
  }

  advice.push({
    icon: "⚡", title: "每日基础代谢", type: "info",
    body: `基础代谢率 (BMR) 约 ${Math.round(bmr)} kcal/天。即使完全静止，身体也需要这么多能量维持生命。`,
  });

  const fatRange = gender === "male" ? { low: 10, high: 20 } : { low: 18, high: 28 };
  if (bodyFat < fatRange.low) {
    advice.push({
      icon: "💀", title: "体脂率过低", type: "danger",
      body: `估算体脂率约 ${bodyFat.toFixed(1)}%，低于健康下限。过低体脂会影响激素分泌和免疫系统。`,
    });
  } else if (bodyFat <= fatRange.high) {
    advice.push({
      icon: "💪", title: "体脂率健康", type: "success",
      body: `估算体脂率约 ${bodyFat.toFixed(1)}%，处于健康范围（${gender === "male" ? "男性 10–20%" : "女性 18–28%"}）。`,
    });
  } else {
    advice.push({
      icon: "🎯", title: "体脂率偏高", type: "warning",
      body: `估算体脂率约 ${bodyFat.toFixed(1)}%。建议增加抗阻训练和适量有氧，逐步降至健康区间。`,
    });
  }

  if (age >= 40) {
    advice.push({
      icon: "🦴", title: "骨骼健康提醒", type: "info",
      body: "40岁后骨密度开始下降，建议补充维生素D和钙质，进行负重训练减缓骨质流失。",
    });
  }

  return advice;
}

function buildQuests(bmi: number, age: number, bodyFat: number, gender: "male" | "female"): Quest[] {
  const cat = bmi < 18.5 ? "underweight" : bmi < 25 ? "normal" : bmi < 30 ? "overweight" : "obese";
  const fatHigh = gender === "male" ? 20 : 28;
  const quests: Quest[] = [];

  quests.push({ id: "hydration", title: "水分补给任务", description: "每天饮用至少 8 杯水（约 2L），连续 7 天", xpReward: 150, difficulty: "E", completed: false, icon: "💧" });
  quests.push({ id: "sleep", title: "睡眠恢复仪式", description: "连续 14 天保证 7–9 小时优质睡眠", xpReward: 300, difficulty: "D", completed: false, icon: "🌙" });

  if (cat === "overweight" || cat === "obese") {
    quests.push({ id: "cardio_boss", title: "有氧讨伐 BOSS 战", description: "连续 30 天每天 30 分钟以上有氧运动", xpReward: 800, difficulty: "B", completed: false, icon: "🏃" });
    quests.push({ id: "calorie_guild", title: "热量控制公会任务", description: "记录饮食日记 21 天，保持每日热量缺口 300–500 kcal", xpReward: 600, difficulty: "C", completed: false, icon: "📖" });
  }
  if (cat === "underweight") {
    quests.push({ id: "bulk_quest", title: "增重冒险之路", description: "每天摄入 1.6g/kg 蛋白质，配合力量训练，月目标增重 1–2 kg", xpReward: 700, difficulty: "C", completed: false, icon: "🥩" });
  }

  quests.push({ id: "strength_legend", title: "力量传说副本", description: "每周 3 次力量训练，连续 8 周不断档", xpReward: 1000, difficulty: "A", completed: false, icon: "🏋️" });

  if (bodyFat > fatHigh) {
    quests.push({ id: "recomp_s", title: "S 级重构计划", description: "坚持 12 周身体重组计划，体脂降低 3% 以上", xpReward: 2000, difficulty: "S", completed: false, icon: "⚔️" });
  }
  if (age >= 40) {
    quests.push({ id: "mobility", title: "柔韧性解锁任务", description: "每周 3 次瑜伽或拉伸训练，持续 4 周", xpReward: 400, difficulty: "D", completed: false, icon: "🧘" });
  }

  return quests;
}

// ─── Main Entry Point ─────────────────────────────────────────────────────

export type ProgressCallback = (msg: string) => void;

export async function runLeoCompute(
  input: FitnessInput,
  onProgress?: ProgressCallback,
): Promise<FitnessResult> {
  const currentYear = new Date().getFullYear();
  const inputs = buildInputs(
    input.heightCm,
    input.weightKg,
    input.birthYear,
    input.gender,
    currentYear,
  );

  let parsed: ParsedFitnessData;
  let executionMode: "zk" | "local" = "local";
  let proofTime = 0;
  let rawOutputs: string[] | null = null;

  const status = await checkSdkStatus();

  if (status.ready) {
    try {
      onProgress?.("Initializing snarkVM WASM prover...");
      const worker = getAleoWorker();

      onProgress?.("Executing fitness_oracle.aleo::compute_fitness ...");
      onProgress?.("Generating R1CS circuit & ZK witness...");

      const result = await worker.executeProgram(
        PROGRAM_SOURCE,
        FUNCTION_NAME,
        inputs,
        false,
      );

      rawOutputs = result.outputs;
      proofTime = result.provingTimeMs;
      executionMode = "zk";

      onProgress?.("Parsing ZK execution outputs...");
      parsed = parseOutputStruct(result.outputs[0]);
    } catch (e: any) {
      console.warn("ZK execution failed, falling back to local:", e);
      onProgress?.("ZK execution failed — switching to local mirror...");
      parsed = computeLocal(input);
      proofTime = 0;
    }
  } else {
    onProgress?.("SDK unavailable — executing local circuit mirror...");
    parsed = computeLocal(input);
  }

  const bmi = parsed.bmi_x100 / 100;
  const bmr = parsed.bmr;
  const bodyFat = parsed.body_fat_x10 / 10;
  const age = parsed.age;
  const cat = categoryFromClass(parsed.fitness_class);

  const h = input.heightCm / 100;
  const idealWeightRange = {
    min: Math.round(18.5 * h * h * 10) / 10,
    max: Math.round(24.9 * h * h * 10) / 10,
  };

  const tdee = {
    sedentary: Math.round(bmr * 1.2),
    light: Math.round(bmr * 1.375),
    moderate: Math.round(bmr * 1.55),
    active: Math.round(bmr * 1.725),
    veryActive: Math.round(bmr * 1.9),
  };

  const proof: FitnessProof = {
    proofHash:
      executionMode === "zk" && rawOutputs
        ? hashString(rawOutputs[0])
        : hashString(JSON.stringify(parsed)),
    executionMode,
    proofTime,
    programId: "fitness_oracle.aleo",
    functionName: "compute_fitness",
    constraints: executionMode === "zk" ? "R1CS (snarkVM)" : "Local mirror",
  };

  return {
    bmi: Math.round(bmi * 100) / 100,
    bmr: Math.round(bmr),
    tdee,
    bodyFatEstimate: Math.round(bodyFat * 10) / 10,
    age,
    idealWeightRange,
    bmiCategory: cat,
    bmiDescription: CATEGORY_DESC[cat],
    healthScore: parsed.health_score,
    advice: buildAdvice(bmi, bmr, bodyFat, age, input.gender),
    quests: buildQuests(bmi, age, bodyFat, input.gender),
    proof,
    leoCode: programSource,
    rawOutputs,
  };
}

function hashString(s: string): string {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  }
  const hex = (Math.abs(h) >>> 0).toString(16).padStart(8, "0");
  return hex.repeat(8);
}
