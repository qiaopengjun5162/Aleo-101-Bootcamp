/**
 * Leo Wallet adapter for Aleo dApps.
 *
 * Leo Wallet injects `window.leoWallet` (or `window.leo`) into the page.
 * This module wraps its API into a clean async interface.
 */

export interface LeoWalletApi {
  connect: (decryptPermission: string, network: string) => Promise<{ address: string }>;
  disconnect: () => Promise<void>;
  requestExecution: (params: {
    programId: string;
    functionName: string;
    inputs: string[];
    fee: number;
  }) => Promise<{ transactionId: string }>;
  getExecution: (transactionId: string) => Promise<unknown>;
  publicKey?: string;
}

declare global {
  interface Window {
    leoWallet?: LeoWalletApi;
    leo?: LeoWalletApi;
  }
}

export function detectLeoWallet(): LeoWalletApi | null {
  return window.leoWallet ?? window.leo ?? null;
}

export function isLeoWalletInstalled(): boolean {
  return detectLeoWallet() !== null;
}

export async function connectLeoWallet(): Promise<{
  address: string;
  wallet: LeoWalletApi;
}> {
  const wallet = detectLeoWallet();
  if (!wallet) {
    throw new Error(
      "Leo Wallet not detected. Please install it from https://www.leo.app/",
    );
  }

  const result = await wallet.connect(
    "NO_DECRYPT",
    "mainnet",
  );

  return { address: result.address, wallet };
}

export async function disconnectLeoWallet(): Promise<void> {
  const wallet = detectLeoWallet();
  if (wallet) {
    await wallet.disconnect();
  }
}

export async function requestWalletExecution(
  wallet: LeoWalletApi,
  programId: string,
  functionName: string,
  inputs: string[],
  fee: number = 1_000_000,
): Promise<string> {
  const result = await wallet.requestExecution({
    programId,
    functionName,
    inputs,
    fee,
  });
  return result.transactionId;
}
