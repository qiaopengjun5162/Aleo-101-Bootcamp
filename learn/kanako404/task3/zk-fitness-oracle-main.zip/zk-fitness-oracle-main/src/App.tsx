import { useState, useCallback, useEffect } from "react";
import {
  runLeoCompute,
  checkSdkStatus,
  createAccount,
  importAccount,
  type FitnessResult,
  type FitnessInput,
  type AleoAccount,
} from "./leoRuntime";
import {
  isLeoWalletInstalled,
  connectLeoWallet,
  disconnectLeoWallet,
} from "./wallet/leoWallet";
import InputScreen from "./components/InputScreen";
import ResultScreen from "./components/ResultScreen";
import LoadingScreen from "./components/LoadingScreen";
import TitleScreen from "./components/TitleScreen";
import ErrorBoundary from "./components/ErrorBoundary";

type Screen = "title" | "input" | "loading" | "result";

export default function App() {
  const [screen, setScreen] = useState<Screen>("title");
  const [result, setResult] = useState<FitnessResult | null>(null);
  const [showLeo, setShowLeo] = useState(false);

  const [account, setAccount] = useState<AleoAccount | null>(null);
  const [sdkReady, setSdkReady] = useState<boolean | null>(null);
  const [loadingMsg, setLoadingMsg] = useState("");
  const [walletInstalled, setWalletInstalled] = useState(false);
  const [walletConnected, setWalletConnected] = useState(false);

  useEffect(() => {
    checkSdkStatus().then((s) => setSdkReady(s.ready));
    const timer = setTimeout(() => setWalletInstalled(isLeoWalletInstalled()), 500);
    return () => clearTimeout(timer);
  }, []);

  const handleConnectWallet = useCallback(async () => {
    try {
      const { address } = await connectLeoWallet();
      setAccount({ address, privateKey: "", viewKey: "" });
      setWalletConnected(true);
    } catch (e: any) {
      console.error("Wallet connection failed:", e);
      throw e;
    }
  }, []);

  const handleDisconnectWallet = useCallback(async () => {
    await disconnectLeoWallet();
    setAccount(null);
    setWalletConnected(false);
  }, []);

  const handleGenerateAccount = useCallback(async () => {
    try {
      const acc = await createAccount();
      setAccount(acc);
    } catch (e) {
      console.error("Account generation failed:", e);
    }
  }, []);

  const handleImportAccount = useCallback(async (pk: string) => {
    try {
      const acc = await importAccount(pk);
      setAccount(acc);
    } catch (e) {
      console.error("Account import failed:", e);
      throw e;
    }
  }, []);

  const handleStart = useCallback(() => {
    setScreen("input");
  }, []);

  const handleCompute = useCallback(async (input: FitnessInput) => {
    setScreen("loading");
    setLoadingMsg("");
    try {
      const res = await runLeoCompute(input, (msg) => setLoadingMsg(msg));
      setResult(res);
      setScreen("result");
    } catch (e) {
      console.error(e);
      setScreen("input");
    }
  }, []);

  const handleReset = useCallback(() => {
    setResult(null);
    setShowLeo(false);
    setScreen("input");
  }, []);

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#050a14]">
      <div className="pointer-events-none fixed inset-0 z-0">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0,255,170,0.04) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0,255,170,0.04) 1px, transparent 1px)
            `,
            backgroundSize: "40px 40px",
            animation: "gridMove 20s linear infinite",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#050a14]/80" />
      </div>

      <Particles />

      <div
        className="pointer-events-none fixed inset-0 z-50"
        style={{
          backgroundImage:
            "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.08) 2px, rgba(0,0,0,0.08) 4px)",
        }}
      />

      <div className="relative z-10">
        <ErrorBoundary onReset={handleReset}>
          {screen === "title" && (
            <TitleScreen
              onStart={handleStart}
              account={account}
              sdkReady={sdkReady}
              onGenerateAccount={handleGenerateAccount}
              onImportAccount={handleImportAccount}
              walletInstalled={walletInstalled}
              walletConnected={walletConnected}
              onConnectWallet={handleConnectWallet}
              onDisconnectWallet={handleDisconnectWallet}
            />
          )}
          {screen === "input" && (
            <InputScreen onCompute={handleCompute} account={account} sdkReady={sdkReady} />
          )}
          {screen === "loading" && (
            <LoadingScreen progressMessage={loadingMsg} sdkReady={sdkReady} />
          )}
          {screen === "result" && result && (
            <ResultScreen
              result={result}
              onReset={handleReset}
              showLeo={showLeo}
              onToggleLeo={() => setShowLeo((v) => !v)}
              account={account}
            />
          )}
        </ErrorBoundary>
      </div>

      <style>{`
        @keyframes gridMove {
          0% { background-position: 0 0; }
          100% { background-position: 40px 40px; }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); opacity: 0.6; }
          50% { transform: translateY(-20px) rotate(180deg); opacity: 1; }
        }
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0; }
        }
        @keyframes scanDown {
          0% { top: -10%; }
          100% { top: 110%; }
        }
        @keyframes glitch {
          0% { transform: translate(0); }
          20% { transform: translate(-2px, 2px); }
          40% { transform: translate(-2px, -2px); }
          60% { transform: translate(2px, 2px); }
          80% { transform: translate(2px, -2px); }
          100% { transform: translate(0); }
        }
        @keyframes typewriter {
          from { width: 0; }
          to { width: 100%; }
        }
        @keyframes hpBar {
          from { width: 0%; }
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulse-green {
          0%, 100% { box-shadow: 0 0 5px rgba(0,255,170,0.3); }
          50% { box-shadow: 0 0 20px rgba(0,255,170,0.8), 0 0 40px rgba(0,255,170,0.4); }
        }
        @keyframes rotateSlow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .pixel-text { font-family: 'Press Start 2P', monospace; }
        .mono-text { font-family: 'Share Tech Mono', monospace; }
        .orbitron { font-family: 'Orbitron', sans-serif; }
        .glow-green { text-shadow: 0 0 10px rgba(0,255,170,0.8), 0 0 20px rgba(0,255,170,0.4); }
        .glow-purple { text-shadow: 0 0 10px rgba(168,85,247,0.8), 0 0 20px rgba(168,85,247,0.4); }
        .glow-yellow { text-shadow: 0 0 10px rgba(250,204,21,0.8), 0 0 20px rgba(250,204,21,0.4); }
        .border-glow { box-shadow: 0 0 0 1px rgba(0,255,170,0.3), inset 0 0 20px rgba(0,255,170,0.05); }
        .btn-rpg {
          position: relative;
          overflow: hidden;
          transition: all 0.2s;
        }
        .btn-rpg::before {
          content: '';
          position: absolute;
          top: 0; left: -100%;
          width: 100%; height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
          transition: left 0.4s;
        }
        .btn-rpg:hover::before { left: 100%; }
        .btn-rpg:active { transform: scale(0.97); }
        .card-rpg {
          background: linear-gradient(135deg, rgba(0,20,40,0.9), rgba(0,10,25,0.95));
          border: 1px solid rgba(0,255,170,0.2);
          backdrop-filter: blur(10px);
        }
        .hp-bar-fill { animation: hpBar 1.2s ease-out forwards; }
        .fade-in-up { animation: fadeInUp 0.5s ease-out forwards; }
      `}</style>
    </div>
  );
}

function Particles() {
  const particles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    size: Math.random() * 3 + 1,
    left: Math.random() * 100,
    delay: Math.random() * 10,
    duration: Math.random() * 8 + 6,
    color:
      i % 3 === 0
        ? "rgba(0,255,170,0.6)"
        : i % 3 === 1
          ? "rgba(168,85,247,0.6)"
          : "rgba(250,204,21,0.5)",
  }));

  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full"
          style={{
            width: p.size,
            height: p.size,
            left: `${p.left}%`,
            bottom: "-10px",
            backgroundColor: p.color,
            animation: `float ${p.duration}s ${p.delay}s ease-in-out infinite`,
            boxShadow: `0 0 ${p.size * 3}px ${p.color}`,
          }}
        />
      ))}
    </div>
  );
}
