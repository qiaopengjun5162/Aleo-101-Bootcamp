import { describe, it, expect } from "vitest";

/**
 * Mirrors the Leo circuit logic in TypeScript for unit testing.
 * This verifies that our local computation produces identical results
 * to what `leo run` produces on-chain.
 */
function computeLocal(
  heightCm: number,
  weightKg: number,
  birthYear: number,
  gender: "male" | "female",
  currentYear: number,
) {
  const age = currentYear - birthYear;
  const bmi_x100 = Math.floor((weightKg * 1_000_000) / (heightCm * heightCm));

  let fitness_class: number;
  if (bmi_x100 < 1850) fitness_class = 0;
  else if (bmi_x100 < 2500) fitness_class = 1;
  else if (bmi_x100 < 3000) fitness_class = 2;
  else fitness_class = 3;

  const bmr_base = 10 * weightKg + 6 * heightCm;
  const age_cost = 5 * age;
  const bmr_pos = bmr_base >= age_cost ? bmr_base - age_cost : 0;
  const bmr =
    gender === "male"
      ? bmr_pos + 5
      : bmr_pos >= 161
        ? bmr_pos - 161
        : 0;

  const bf_pos = Math.floor((120 * bmi_x100) / 100) + 23 * age;
  const bf_neg = gender === "male" ? 1620 : 540;
  const body_fat_x10 =
    bf_pos >= bf_neg ? Math.floor((bf_pos - bf_neg) / 10) : 0;

  const bmi_diff =
    bmi_x100 >= 2200 ? bmi_x100 - 2200 : 2200 - bmi_x100;
  const raw_penalty = Math.floor(bmi_diff / 50);
  const capped = raw_penalty >= 80 ? 80 : raw_penalty;
  const health_score = 100 - capped;

  return { bmi_x100, bmr, body_fat_x10, fitness_class, health_score, age };
}

describe("computeLocal (TypeScript mirror of Leo circuit)", () => {
  it("normal male: 175cm 70kg born 1995", () => {
    const r = computeLocal(175, 70, 1995, "male", 2026);
    expect(r.bmi_x100).toBe(2285);
    expect(r.fitness_class).toBe(1);
    expect(r.age).toBe(31);
    expect(r.health_score).toBe(99);
    expect(r.bmr).toBe(1600);
  });

  it("normal female: 165cm 55kg born 2000", () => {
    const r = computeLocal(165, 55, 2000, "female", 2026);
    expect(r.bmi_x100).toBe(2020);
    expect(r.fitness_class).toBe(1);
    expect(r.age).toBe(26);
    expect(r.bmr).toBe(1249);
  });

  it("underweight male: 180cm 50kg", () => {
    const r = computeLocal(180, 50, 1998, "male", 2026);
    expect(r.bmi_x100).toBe(1543);
    expect(r.fitness_class).toBe(0);
    expect(r.health_score).toBe(87);
  });

  it("overweight male: 170cm 85kg", () => {
    const r = computeLocal(170, 85, 1990, "male", 2026);
    expect(r.bmi_x100).toBe(2941);
    expect(r.fitness_class).toBe(2);
  });

  it("obese male: 170cm 100kg", () => {
    const r = computeLocal(170, 100, 1990, "male", 2026);
    expect(r.bmi_x100).toBe(3460);
    expect(r.fitness_class).toBe(3);
    expect(r.health_score).toBe(75);
    expect(r.bmr).toBe(1845);
  });

  it("elderly female: 160cm 60kg born 1960", () => {
    const r = computeLocal(160, 60, 1960, "female", 2026);
    expect(r.age).toBe(66);
    expect(r.bmr).toBeGreaterThan(0);
  });

  it("matches leo run output for normal male", () => {
    // These expected values come directly from `leo run compute_fitness 175u32 70u32 1995u32 1u8 2026u32`
    const r = computeLocal(175, 70, 1995, "male", 2026);
    expect(r.bmi_x100).toBe(2285);
    expect(r.bmr).toBe(1600);
    expect(r.body_fat_x10).toBe(183);
    expect(r.fitness_class).toBe(1);
    expect(r.health_score).toBe(99);
    expect(r.age).toBe(31);
  });

  it("matches leo run output for obese male", () => {
    // From `leo run compute_fitness 170u32 100u32 1990u32 1u8 2026u32`
    const r = computeLocal(170, 100, 1990, "male", 2026);
    expect(r.bmi_x100).toBe(3460);
    expect(r.bmr).toBe(1845);
    expect(r.body_fat_x10).toBe(336);
    expect(r.fitness_class).toBe(3);
    expect(r.health_score).toBe(75);
    expect(r.age).toBe(36);
  });

  it("matches leo run output for normal female", () => {
    // From `leo run compute_fitness 165u32 55u32 2000u32 0u8 2026u32`
    const r = computeLocal(165, 55, 2000, "female", 2026);
    expect(r.bmi_x100).toBe(2020);
    expect(r.bmr).toBe(1249);
    expect(r.body_fat_x10).toBe(248);
    expect(r.fitness_class).toBe(1);
    expect(r.health_score).toBe(97);
    expect(r.age).toBe(26);
  });

  it("matches leo run output for underweight male", () => {
    // From `leo run compute_fitness 180u32 50u32 1998u32 1u8 2026u32`
    const r = computeLocal(180, 50, 1998, "male", 2026);
    expect(r.bmi_x100).toBe(1543);
    expect(r.bmr).toBe(1445);
    expect(r.body_fat_x10).toBe(87);
    expect(r.fitness_class).toBe(0);
    expect(r.health_score).toBe(87);
    expect(r.age).toBe(28);
  });
});
