import { describe, it, expect } from "vitest";
import { buildInputs, parseOutputStruct } from "../aleo/program";

describe("buildInputs", () => {
  it("should format male inputs correctly", () => {
    const result = buildInputs(175, 70, 1995, "male", 2026);
    expect(result).toEqual(["175u32", "70u32", "1995u32", "1u8", "2026u32"]);
  });

  it("should format female inputs correctly", () => {
    const result = buildInputs(165, 55, 2000, "female", 2026);
    expect(result).toEqual(["165u32", "55u32", "2000u32", "0u8", "2026u32"]);
  });
});

describe("parseOutputStruct", () => {
  it("should parse Leo output struct correctly", () => {
    const output = `{
  bmi_x100: 2285u32,
  bmr: 1600u32,
  body_fat_x10: 183u32,
  fitness_class: 1u8,
  health_score: 99u8,
  age: 31u8
}`;
    const parsed = parseOutputStruct(output);
    expect(parsed.bmi_x100).toBe(2285);
    expect(parsed.bmr).toBe(1600);
    expect(parsed.body_fat_x10).toBe(183);
    expect(parsed.fitness_class).toBe(1);
    expect(parsed.health_score).toBe(99);
    expect(parsed.age).toBe(31);
  });

  it("should handle zero values", () => {
    const output = `{
  bmi_x100: 0u32,
  bmr: 0u32,
  body_fat_x10: 0u32,
  fitness_class: 0u8,
  health_score: 0u8,
  age: 0u8
}`;
    const parsed = parseOutputStruct(output);
    expect(parsed.bmi_x100).toBe(0);
    expect(parsed.health_score).toBe(0);
  });
});
