import { useState, useEffect } from "react";

interface Props {
  progressMessage: string;
  sdkReady: boolean | null;
}

const ZK_STEPS = [
  { label: "Loading Aleo program...", detail: "fitness_oracle.aleo", icon: "📦" },
  { label: "Building R1CS circuit...", detail: "Arithmetic constraint system from Leo", icon: "⚙️" },
  { label: "Generating ZK witness...", detail: "Private inputs → circuit wire values", icon: "🔐" },
  { label: "Computing snarkVM proof...", detail: "Groth16 prover over BLS12-377", icon: "⚡" },
  { label: "Verifying execution...", detail: "Output integrity check", icon: "✅" },
];

const LOCAL_STEPS = [
  { label: "Loading Leo circuit mirror...", detail: "fitness_oracle.aleo (local)", icon: "📦" },
  { label: "Executing circuit logic...", detail: "Integer arithmetic: BMI, BMR, BF%", icon: "⚙️" },
  { label: "Computing fitness data...", detail: "Health score & classification", icon: "⚡" },
  { label: "Building result struct...", detail: "FitnessData { bmi_x100, bmr, ... }", icon: "✅" },
];

export default function LoadingScreen({ progressMessage, sdkReady }: Props) {
  const STEPS = sdkReady ? ZK_STEPS : LOCAL_STEPS;
  const [step, setStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [dots, setDots] = useState("");
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    const logLines = sdkReady
      ? [
          "> import fitness_oracle.aleo",
          '  Program ID: "fitness_oracle.aleo"',
          "  Function: compute_fitness",
          "  Inputs: [private u32, private u32, private u32, private u8, public u32]",
          "> snarkvm::synthesize",
          "  Building R1CS — counting gates...",
          "  Witness generation complete",
          "> snarkvm::prove (Groth16, BLS12-377)",
          "  Proof generation in progress...",
          "  ✓ Execution successful",
          "  Output: FitnessData { ... }",
        ]
      : [
          "> load fitness_oracle.aleo (local mirror)",
          '  Program: "fitness_oracle.aleo"',
          "  Mode: Leo circuit integer arithmetic",
          "> execute compute_fitness",
          "  BMI = weight × 1000000 / height²",
          "  BMR = 10W + 6H − 5A ± offset",
          "  BodyFat = Deurenberg(BMI, age, gender)",
          "  HealthScore = 100 − |BMI−22|/0.5",
          "  ✓ Computation complete",
          "  Output: FitnessData { ... }",
        ];

    setLogs([]);
    let i = 0;
    const t = setInterval(() => {
      if (i < logLines.length) {
        const line = logLines[i];
        setLogs((prev) => [...prev, line]);
        i++;
      } else {
        clearInterval(t);
      }
    }, 150);
    return () => clearInterval(t);
  }, [sdkReady]);

  useEffect(() => {
    const d = sdkReady ? 400 : 250;
    const t = setInterval(() => {
      setStep((s) => Math.min(s + 1, STEPS.length - 1));
    }, d);
    return () => clearInterval(t);
  }, [STEPS.length, sdkReady]);

  useEffect(() => {
    const t = setInterval(() => {
      setProgress((p) => Math.min(p + 1, 100));
    }, sdkReady ? 20 : 12);
    return () => clearInterval(t);
  }, [sdkReady]);

  useEffect(() => {
    const t = setInterval(() => setDots((d) => (d.length >= 3 ? "" : d + ".")), 400);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      <div className="pixel-text text-[8px] text-[#00ffaa]/50 mb-2 tracking-widest">
        {sdkReady ? "— ZK PROOF GENERATION —" : "— LOCAL CIRCUIT EXECUTION —"}
      </div>

      {progressMessage && (
        <div className="mono-text text-[10px] text-purple-300 mb-6 text-center max-w-md">
          {progressMessage}
        </div>
      )}

      {/* Animated sphere */}
      <div className="relative mb-10 w-40 h-40">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="absolute inset-0 rounded-full border border-[#00ffaa]/20"
            style={{
              transform: `scale(${1 + i * 0.25})`,
              animation: `rotateSlow ${6 + i * 2}s linear infinite ${i % 2 === 0 ? "" : "reverse"}`,
              borderStyle: i === 1 ? "dashed" : "solid",
            }}
          />
        ))}
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            className="w-20 h-20 rounded-full bg-gradient-to-br from-[#00ffaa]/20 to-purple-900/30 border border-[#00ffaa]/40 flex items-center justify-center"
            style={{ animation: "pulse-green 1.5s ease-in-out infinite" }}
          >
            <span className="text-3xl">{STEPS[step]?.icon || "⚡"}</span>
          </div>
        </div>
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <div
            key={i}
            className="absolute w-1.5 h-1.5 rounded-full bg-[#00ffaa]"
            style={{
              top: "50%",
              left: "50%",
              marginTop: "-3px",
              marginLeft: "-3px",
              transform: `rotate(${i * 60}deg) translateX(65px)`,
              animation: "rotateSlow 3s linear infinite",
              transformOrigin: "3px 3px",
              boxShadow: "0 0 6px rgba(0,255,170,1)",
              animationDelay: `${-i * 0.5}s`,
            }}
          />
        ))}
      </div>

      {/* Progress bar */}
      <div className="w-full max-w-md mb-6 px-4">
        <div className="flex justify-between mb-2">
          <span className="pixel-text text-[8px] text-[#00ffaa]/60">
            {sdkReady ? "ZK EXECUTION" : "LOCAL EXECUTION"}
          </span>
          <span className="pixel-text text-[8px] text-[#00ffaa]">{progress}%</span>
        </div>
        <div className="h-3 bg-black/60 rounded-full border border-[#00ffaa]/20 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#00ffaa] to-[#00ddff] rounded-full transition-all duration-100"
            style={{
              width: `${progress}%`,
              boxShadow: "0 0 10px rgba(0,255,170,0.6)",
            }}
          />
        </div>
      </div>

      {/* Steps */}
      <div className="w-full max-w-md space-y-2 mb-8 px-4">
        {STEPS.map((s, i) => (
          <div
            key={i}
            className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-300 ${
              i < step
                ? "opacity-40"
                : i === step
                  ? "bg-[#00ffaa]/10 border border-[#00ffaa]/30"
                  : "opacity-20"
            }`}
          >
            <span className="text-base">{i < step ? "✓" : s.icon}</span>
            <div className="flex-1">
              <div className="mono-text text-xs text-white">
                {s.label}
                {i === step ? dots : ""}
              </div>
              {i === step && (
                <div className="mono-text text-[10px] text-gray-400 mt-0.5">
                  {s.detail}
                </div>
              )}
            </div>
            {i < step && <span className="text-[#00ffaa] text-xs">✓</span>}
            {i === step && (
              <div className="flex gap-1">
                {[0, 1, 2].map((j) => (
                  <div
                    key={j}
                    className="w-1 h-1 rounded-full bg-[#00ffaa]"
                    style={{
                      animation: `blink 1s ${j * 0.2}s ease-in-out infinite`,
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Console */}
      <div className="w-full max-w-md bg-black/60 rounded-lg border border-gray-700/50 overflow-hidden">
        <div className="flex items-center gap-2 px-3 py-2 border-b border-gray-700/50 bg-black/40">
          <div className="w-3 h-3 rounded-full bg-red-500/70" />
          <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
          <div className="w-3 h-3 rounded-full bg-green-500/70" />
          <span className="mono-text text-[10px] text-gray-500 ml-2">
            {sdkReady ? "snarkvm-wasm" : "leo-local"}
          </span>
        </div>
        <div className="p-3 h-28 overflow-y-auto">
          {logs
            .filter((log): log is string => typeof log === "string")
            .map((log, i) => (
              <div
                key={i}
                className={`mono-text text-[10px] leading-relaxed ${
                  log.startsWith(">")
                    ? "text-[#00ffaa]"
                    : log.includes("✓")
                      ? "text-green-400"
                      : "text-gray-500"
                }`}
              >
                {log}
              </div>
            ))}
        </div>
      </div>

      <div className="mt-6 pixel-text text-[8px] text-[#00ffaa]/40">
        🔒 你的 private 数据受零知识证明保护 · PRIVATE BY DEFAULT
      </div>
    </div>
  );
}
