import { useState } from "react";
import type { FitnessResult, Quest, AdviceEntry, AleoAccount } from "../leoRuntime";

interface Props {
  result: FitnessResult;
  onReset: () => void;
  showLeo: boolean;
  onToggleLeo: () => void;
  account: AleoAccount | null;
}

const CATEGORY_COLORS: Record<string, string> = {
  underweight: "#60a5fa",
  normal: "#00ffaa",
  overweight: "#fbbf24",
  obese: "#f87171",
};

const CATEGORY_LABELS: Record<string, string> = {
  underweight: "体重不足",
  normal: "健康体重",
  overweight: "超重",
  obese: "肥胖",
};

const ADVICE_COLORS = {
  success: "border-[#00ffaa]/30 bg-[#00ffaa]/5",
  info: "border-blue-400/30 bg-blue-900/10",
  warning: "border-yellow-400/30 bg-yellow-900/10",
  danger: "border-red-400/30 bg-red-900/15",
};

const ADVICE_LABEL_COLORS = {
  success: "text-[#00ffaa]",
  info: "text-blue-400",
  warning: "text-yellow-400",
  danger: "text-red-400",
};

const DIFF_COLORS: Record<string, string> = {
  E: "text-gray-400 border-gray-600",
  D: "text-green-400 border-green-600",
  C: "text-blue-400 border-blue-600",
  B: "text-yellow-400 border-yellow-600",
  A: "text-orange-400 border-orange-600",
  S: "text-red-400 border-red-500 shadow-[0_0_8px_rgba(248,113,113,0.4)]",
};

export default function ResultScreen({
  result,
  onReset,
  showLeo,
  onToggleLeo,
  account,
}: Props) {
  const [activeTab, setActiveTab] = useState<"stats" | "advice" | "quests" | "proof">("stats");
  const [completedQuests, setCompletedQuests] = useState<Set<string>>(new Set());
  const [copiedProof, setCopiedProof] = useState(false);

  const catColor = CATEGORY_COLORS[result.bmiCategory];

  const toggleQuest = (id: string) => {
    setCompletedQuests((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const totalXP = result.quests
    .filter((q) => completedQuests.has(q.id))
    .reduce((sum, q) => sum + q.xpReward, 0);

  const copyProof = () => {
    navigator.clipboard.writeText(result.proof.proofHash);
    setCopiedProof(true);
    setTimeout(() => setCopiedProof(false), 2000);
  };

  return (
    <div className="min-h-screen px-4 py-8 max-w-2xl mx-auto">
      <div className="text-center mb-6 fade-in-up">
        <div className="pixel-text text-[8px] text-[#00ffaa]/50 mb-3 tracking-widest">
          — ANALYSIS COMPLETE —
        </div>
        <h2 className="pixel-text text-lg text-white">
          健身<span className="glow-green" style={{ color: catColor }}>角色</span>档案
        </h2>
        {/* Execution mode badge */}
        <div className="mt-2 inline-flex items-center gap-2 px-3 py-1 rounded-full border border-purple-500/30 bg-purple-900/20">
          <div
            className={`w-1.5 h-1.5 rounded-full ${
              result.proof.executionMode === "zk" ? "bg-green-400" : "bg-yellow-400"
            }`}
          />
          <span className="mono-text text-[10px] text-purple-300">
            {result.proof.executionMode === "zk"
              ? "ZK Verified · snarkVM"
              : "Local Verified · Circuit Mirror"}
          </span>
        </div>
      </div>

      {/* Character Card */}
      <div
        className="card-rpg rounded-xl p-5 mb-5 fade-in-up"
        style={{ borderColor: `${catColor}30` }}
      >
        <div className="flex flex-col md:flex-row items-center gap-5">
          <div className="relative flex-shrink-0">
            <div
              className="w-24 h-24 rounded-full border-2 flex items-center justify-center text-4xl bg-black/40"
              style={{
                borderColor: catColor,
                boxShadow: `0 0 20px ${catColor}40`,
              }}
            >
              {result.bmiCategory === "underweight"
                ? "🌱"
                : result.bmiCategory === "normal"
                  ? "⚔️"
                  : result.bmiCategory === "overweight"
                    ? "🛡️"
                    : "🐉"}
            </div>
            <div
              className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-black border-2 flex items-center justify-center text-xs"
              style={{ borderColor: catColor }}
            >
              Lv{Math.floor(result.healthScore / 10)}
            </div>
          </div>

          <div className="flex-1 w-full">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-3">
              <div className="pixel-text text-[10px] text-white">
                {CATEGORY_LABELS[result.bmiCategory]}
              </div>
              <div
                className="sm:ml-auto mono-text text-[10px] px-2 py-0.5 rounded-full border"
                style={{ color: catColor, borderColor: `${catColor}50` }}
              >
                BMI {result.bmi}
              </div>
            </div>

            <div className="mb-2">
              <div className="flex justify-between mb-1">
                <span className="mono-text text-[10px] text-gray-400">HP (健康值)</span>
                <span className="mono-text text-[10px]" style={{ color: catColor }}>
                  {result.healthScore}/100
                </span>
              </div>
              <div className="h-3 bg-black/60 rounded-full border border-gray-700/50 overflow-hidden">
                <div
                  className="h-full rounded-full hp-bar-fill"
                  style={{
                    width: `${result.healthScore}%`,
                    background: `linear-gradient(90deg, ${catColor}aa, ${catColor})`,
                    boxShadow: `0 0 8px ${catColor}80`,
                  }}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 mt-3">
              {[
                { label: "年龄", value: `${result.age}岁` },
                { label: "基础代谢", value: `${result.bmr}kcal` },
                { label: "体脂估算", value: `${result.bodyFatEstimate}%` },
              ].map((s) => (
                <div key={s.label} className="text-center bg-black/30 rounded-lg py-2 px-1">
                  <div className="orbitron text-sm font-bold" style={{ color: catColor }}>
                    {s.value}
                  </div>
                  <div className="mono-text text-[9px] text-gray-500 mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-4 gap-1 mb-5 bg-black/40 rounded-lg p-1 border border-gray-700/40">
        {(
          [
            { key: "stats", label: "数据", icon: "📊" },
            { key: "advice", label: "建议", icon: "🧠" },
            { key: "quests", label: "任务", icon: "⚔️" },
            { key: "proof", label: "证明", icon: "🔒" },
          ] as const
        ).map((t) => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            className={`btn-rpg py-2 px-1 rounded-md transition-all duration-200 flex flex-col items-center gap-0.5 ${
              activeTab === t.key
                ? "bg-[#00ffaa]/15 border border-[#00ffaa]/40 text-[#00ffaa]"
                : "text-gray-500 hover:text-gray-300"
            }`}
          >
            <span className="text-base">{t.icon}</span>
            <span className="pixel-text text-[8px]">{t.label}</span>
          </button>
        ))}
      </div>

      <div className="fade-in-up">
        {activeTab === "stats" && <StatsTab result={result} catColor={catColor} />}
        {activeTab === "advice" && <AdviceTab advice={result.advice} />}
        {activeTab === "quests" && (
          <QuestsTab
            quests={result.quests}
            completedQuests={completedQuests}
            totalXP={totalXP}
            onToggle={toggleQuest}
          />
        )}
        {activeTab === "proof" && (
          <ProofTab
            result={result}
            showLeo={showLeo}
            onToggleLeo={onToggleLeo}
            onCopy={copyProof}
            copied={copiedProof}
            account={account}
          />
        )}
      </div>

      <div className="mt-8 text-center">
        <button
          onClick={onReset}
          className="btn-rpg pixel-text text-[9px] px-6 py-3 border border-gray-600 text-gray-400 rounded-lg hover:border-[#00ffaa]/50 hover:text-[#00ffaa] transition-all duration-200"
        >
          ↩ 重新计算 / RESTART
        </button>
      </div>
    </div>
  );
}

// ── Stats Tab ───────────────────────────────────────────────────────────

function StatsTab({ result, catColor }: { result: FitnessResult; catColor: string }) {
  const bmiScale = [
    { label: "极低", min: 10, max: 18.5, color: "#60a5fa" },
    { label: "正常", min: 18.5, max: 25, color: "#00ffaa" },
    { label: "偏重", min: 25, max: 30, color: "#fbbf24" },
    { label: "肥胖", min: 30, max: 40, color: "#f87171" },
  ];

  const bmiPercent = Math.min(100, Math.max(0, ((result.bmi - 10) / 30) * 100));

  return (
    <div className="space-y-4">
      <div className="card-rpg rounded-xl p-5">
        <div className="pixel-text text-[9px] text-[#00ffaa] mb-4">◆ BMI 指数分析</div>
        <div className="flex items-center justify-between mb-2">
          <span className="orbitron text-3xl font-black" style={{ color: catColor }}>
            {result.bmi}
          </span>
          <div className="text-right">
            <div className="mono-text text-xs" style={{ color: catColor }}>
              {CATEGORY_LABELS[result.bmiCategory]}
            </div>
            <div className="mono-text text-[10px] text-gray-500">
              正常区间: {result.idealWeightRange.min}–{result.idealWeightRange.max} kg
            </div>
          </div>
        </div>
        <div className="relative mb-4">
          <div className="flex h-4 rounded-full overflow-hidden">
            {bmiScale.map((s) => (
              <div key={s.label} className="flex-1 h-full opacity-40" style={{ background: s.color }} />
            ))}
          </div>
          <div
            className="absolute top-0 h-4 w-0.5 bg-white shadow-lg rounded-full transition-all duration-1000"
            style={{ left: `${bmiPercent}%`, boxShadow: `0 0 8px ${catColor}` }}
          />
          <div className="flex justify-between mt-1">
            {bmiScale.map((s) => (
              <span key={s.label} className="mono-text text-[9px]" style={{ color: s.color }}>
                {s.label}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="card-rpg rounded-xl p-5">
        <div className="pixel-text text-[9px] text-[#00ffaa] mb-4">◆ 每日消耗热量 (TDEE)</div>
        <div className="space-y-2">
          {[
            { label: "久坐不动", icon: "🪑", val: result.tdee.sedentary, factor: "×1.2" },
            { label: "轻度运动 (1–3天/周)", icon: "🚶", val: result.tdee.light, factor: "×1.375" },
            { label: "中度运动 (3–5天/周)", icon: "🏃", val: result.tdee.moderate, factor: "×1.55" },
            { label: "高强度 (6–7天/周)", icon: "🏋️", val: result.tdee.active, factor: "×1.725" },
            { label: "运动员训练", icon: "⚡", val: result.tdee.veryActive, factor: "×1.9" },
          ].map((row, i) => (
            <div
              key={i}
              className="flex items-center gap-3 py-2 px-3 rounded-lg bg-black/30 border border-gray-700/30"
            >
              <span className="text-base">{row.icon}</span>
              <span className="mono-text text-xs text-gray-300 flex-1">{row.label}</span>
              <span className="mono-text text-[10px] text-gray-600">{row.factor}</span>
              <span
                className="orbitron text-sm font-bold"
                style={{ color: i === 2 ? catColor : "#9ca3af" }}
              >
                {row.val}
              </span>
              <span className="mono-text text-[9px] text-gray-600">kcal</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {[
          { icon: "🧬", label: "基础代谢 BMR", value: `${result.bmr}`, unit: "kcal/天", desc: "Mifflin-St Jeor 公式" },
          { icon: "💪", label: "体脂率估算", value: `${result.bodyFatEstimate}`, unit: "%", desc: "Deurenberg 公式" },
          { icon: "🎯", label: "理想体重下限", value: `${result.idealWeightRange.min}`, unit: "kg", desc: "BMI=18.5" },
          { icon: "🏆", label: "理想体重上限", value: `${result.idealWeightRange.max}`, unit: "kg", desc: "BMI=24.9" },
        ].map((c) => (
          <div key={c.label} className="card-rpg rounded-xl p-4">
            <div className="text-xl mb-2">{c.icon}</div>
            <div className="mono-text text-[10px] text-gray-500 mb-1">{c.label}</div>
            <div className="flex items-baseline gap-1">
              <span className="orbitron text-xl font-bold" style={{ color: catColor }}>
                {c.value}
              </span>
              <span className="mono-text text-[10px] text-gray-500">{c.unit}</span>
            </div>
            <div className="mono-text text-[9px] text-gray-600 mt-1">{c.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Advice Tab ──────────────────────────────────────────────────────────

function AdviceTab({ advice }: { advice: AdviceEntry[] }) {
  return (
    <div className="space-y-3">
      <div className="pixel-text text-[8px] text-[#00ffaa]/50 mb-4 tracking-widest text-center">
        — HEALTH ADVISOR —
      </div>
      {advice.map((a, i) => (
        <div
          key={i}
          className={`rounded-xl p-4 border transition-all duration-200 hover:scale-[1.01] fade-in-up ${ADVICE_COLORS[a.type]}`}
          style={{ animationDelay: `${i * 0.1}s` }}
        >
          <div className="flex items-start gap-3">
            <span className="text-2xl flex-shrink-0">{a.icon}</span>
            <div>
              <div className={`pixel-text text-[9px] mb-2 ${ADVICE_LABEL_COLORS[a.type]}`}>
                {a.title}
              </div>
              <div className="mono-text text-xs text-gray-300 leading-relaxed">{a.body}</div>
            </div>
          </div>
        </div>
      ))}

      <div className="card-rpg rounded-xl p-4 mt-4">
        <div className="pixel-text text-[9px] text-[#00ffaa] mb-3">◆ 宏量营养素参考</div>
        <div className="grid grid-cols-3 gap-2">
          {[
            { name: "蛋白质", color: "#60a5fa", pct: "25–35%", note: "1.6–2.2 g/kg", icon: "🥩" },
            { name: "碳水化合物", color: "#fbbf24", pct: "40–50%", note: "复合为主", icon: "🌾" },
            { name: "脂肪", color: "#a78bfa", pct: "20–35%", note: "健康脂肪", icon: "🥑" },
          ].map((n) => (
            <div key={n.name} className="text-center bg-black/30 rounded-lg p-3">
              <div className="text-2xl mb-1">{n.icon}</div>
              <div className="mono-text text-[10px] font-bold mb-1" style={{ color: n.color }}>
                {n.pct}
              </div>
              <div className="mono-text text-[9px] text-gray-400">{n.name}</div>
              <div className="mono-text text-[9px] text-gray-600 mt-1">{n.note}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Quests Tab ──────────────────────────────────────────────────────────

function QuestsTab({
  quests,
  completedQuests,
  totalXP,
  onToggle,
}: {
  quests: Quest[];
  completedQuests: Set<string>;
  totalXP: number;
  onToggle: (id: string) => void;
}) {
  const maxXP = quests.reduce((s, q) => s + q.xpReward, 0);
  const xpPct = maxXP > 0 ? (totalXP / maxXP) * 100 : 0;

  return (
    <div className="space-y-3">
      <div className="card-rpg rounded-xl p-4 mb-2">
        <div className="flex justify-between items-center mb-2">
          <span className="pixel-text text-[9px] text-[#00ffaa]">⚡ 经验值 / XP</span>
          <span className="orbitron text-sm text-[#00ffaa] glow-green">
            {totalXP} / {maxXP}
          </span>
        </div>
        <div className="h-4 bg-black/60 rounded-full border border-[#00ffaa]/20 overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${xpPct}%`,
              background: "linear-gradient(90deg, #00ffaa, #00ddff)",
              boxShadow: "0 0 10px rgba(0,255,170,0.6)",
            }}
          />
        </div>
        <div className="mono-text text-[9px] text-gray-500 mt-1 text-right">
          {completedQuests.size}/{quests.length} 任务完成
        </div>
      </div>

      <div className="pixel-text text-[8px] text-[#00ffaa]/50 text-center tracking-widest mb-2">
        — ACTIVE QUEST LOG —
      </div>

      {quests.map((q, i) => {
        const done = completedQuests.has(q.id);
        return (
          <button
            key={q.id}
            onClick={() => onToggle(q.id)}
            className={`w-full text-left card-rpg rounded-xl p-4 transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] ${
              done
                ? "opacity-60 border-[#00ffaa]/10"
                : "border-[#00ffaa]/15 hover:border-[#00ffaa]/30"
            }`}
            style={{ animationDelay: `${i * 0.08}s` }}
          >
            <div className="flex items-start gap-3">
              <div
                className={`flex-shrink-0 w-6 h-6 mt-0.5 rounded border-2 flex items-center justify-center transition-all ${
                  done ? "bg-[#00ffaa] border-[#00ffaa]" : "border-gray-600"
                }`}
              >
                {done && <span className="text-black text-sm font-bold">✓</span>}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="text-base">{q.icon}</span>
                  <span
                    className={`pixel-text text-[9px] ${done ? "line-through text-gray-500" : "text-white"}`}
                  >
                    {q.title}
                  </span>
                  <span
                    className={`flex-shrink-0 pixel-text text-[8px] px-1.5 py-0.5 rounded border ${DIFF_COLORS[q.difficulty]}`}
                  >
                    {q.difficulty}
                  </span>
                </div>
                <div className="mono-text text-[10px] text-gray-400 leading-relaxed">
                  {q.description}
                </div>
              </div>
              <div className="flex-shrink-0 text-right">
                <div className="orbitron text-sm font-bold text-yellow-400 glow-yellow">
                  +{q.xpReward}
                </div>
                <div className="mono-text text-[9px] text-gray-600">XP</div>
              </div>
            </div>
          </button>
        );
      })}

      {completedQuests.size === quests.length && quests.length > 0 && (
        <div className="card-rpg rounded-xl p-5 text-center border-yellow-400/30 bg-yellow-900/10">
          <div className="text-4xl mb-2">🏆</div>
          <div className="pixel-text text-[10px] text-yellow-400 glow-yellow">
            全任务完成！传说级健身勇者
          </div>
        </div>
      )}
    </div>
  );
}

// ── Proof Tab ───────────────────────────────────────────────────────────

function ProofTab({
  result,
  showLeo,
  onToggleLeo,
  onCopy,
  copied,
  account,
}: {
  result: FitnessResult;
  showLeo: boolean;
  onToggleLeo: () => void;
  onCopy: () => void;
  copied: boolean;
  account: AleoAccount | null;
}) {
  const isZk = result.proof.executionMode === "zk";

  return (
    <div className="space-y-4">
      {/* Verification banner */}
      <div
        className={`rounded-xl border p-4 flex items-center gap-3 ${
          isZk
            ? "border-[#00ffaa]/30 bg-[#00ffaa]/5"
            : "border-yellow-400/30 bg-yellow-900/5"
        }`}
      >
        <div
          className={`w-10 h-10 rounded-full border flex items-center justify-center text-xl flex-shrink-0 ${
            isZk
              ? "border-[#00ffaa]/50 bg-[#00ffaa]/10"
              : "border-yellow-400/50 bg-yellow-900/10"
          }`}
          style={isZk ? { animation: "pulse-green 2s ease-in-out infinite" } : {}}
        >
          {isZk ? "✓" : "◉"}
        </div>
        <div>
          <div
            className={`pixel-text text-[10px] ${isZk ? "text-[#00ffaa] glow-green" : "text-yellow-400"}`}
          >
            {isZk ? "ZK PROOF VERIFIED" : "LOCAL EXECUTION VERIFIED"}
          </div>
          <div className="mono-text text-[10px] text-gray-400 mt-0.5">
            {isZk
              ? "零知识证明有效 · snarkVM 执行验证通过"
              : "本地电路镜像执行 · 结果与 Leo 程序一致"}
          </div>
        </div>
      </div>

      {/* Proof details */}
      <div className="card-rpg rounded-xl p-4">
        <div className="pixel-text text-[9px] text-[#00ffaa] mb-3">◆ 执行详情</div>
        <div className="space-y-2">
          {[
            { label: "Program ID", value: result.proof.programId },
            { label: "Function", value: result.proof.functionName },
            { label: "Execution Mode", value: isZk ? "ZK (snarkVM WASM)" : "Local (Circuit Mirror)" },
            { label: "Execution Hash", value: result.proof.proofHash.slice(0, 24) + "...", copy: true },
            { label: "Proving Time", value: `${result.proof.proofTime} ms` },
            { label: "Constraint System", value: result.proof.constraints },
            { label: "Privacy Level", value: "PRIVATE — all inputs hidden" },
            ...(account
              ? [{ label: "Account", value: account.address.slice(0, 16) + "..." }]
              : []),
          ].map((row) => (
            <div
              key={row.label}
              className="flex items-center gap-2 py-2 px-3 rounded-lg bg-black/30 border border-gray-700/30"
            >
              <span className="mono-text text-[10px] text-gray-500 flex-1 flex-shrink-0 min-w-0">
                {row.label}
              </span>
              <span className="mono-text text-[10px] text-[#00ffaa] font-mono truncate max-w-[55%] text-right">
                {row.value}
              </span>
              {"copy" in row && row.copy && (
                <button
                  onClick={onCopy}
                  className="flex-shrink-0 text-gray-600 hover:text-[#00ffaa] transition-colors"
                >
                  <span className="text-xs">{copied ? "✓" : "📋"}</span>
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Raw ZK outputs */}
      {result.rawOutputs && (
        <div className="card-rpg rounded-xl p-4">
          <div className="pixel-text text-[9px] text-purple-400 mb-3">◆ ZK 执行原始输出</div>
          <pre className="mono-text text-[10px] text-purple-300/80 leading-relaxed bg-black/30 rounded-lg p-3 overflow-x-auto whitespace-pre-wrap">
            {result.rawOutputs.join("\n")}
          </pre>
        </div>
      )}

      {/* Privacy explanation */}
      <div className="card-rpg rounded-xl p-4 border-purple-500/20">
        <div className="pixel-text text-[9px] text-purple-400 mb-3">◆ 零知识证明原理</div>
        <div className="space-y-2">
          {[
            { icon: "🔒", text: "身高、体重、出生年份、性别作为 private 输入，不出现在证明中" },
            { icon: "✅", text: "验证者只能确认「计算结果正确」，无法获知原始数据" },
            { icon: "🧮", text: "Leo 程序编译为 R1CS 算术约束系统，由 Groth16 证明系统验证" },
            { icon: "⛓️", text: "证明可以发布到 Aleo 链上，任何人可验证，但无法反推隐私信息" },
          ].map((item) => (
            <div key={item.text} className="flex items-start gap-2">
              <span className="text-sm flex-shrink-0">{item.icon}</span>
              <span className="mono-text text-[10px] text-gray-400 leading-relaxed">{item.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Leo source code toggle */}
      <div className="card-rpg rounded-xl overflow-hidden">
        <button
          onClick={onToggleLeo}
          className="w-full flex items-center justify-between px-4 py-3 hover:bg-[#00ffaa]/5 transition-colors"
        >
          <div className="flex items-center gap-2">
            <span className="text-base">📜</span>
            <span className="pixel-text text-[9px] text-[#00ffaa]">
              查看 Leo / Aleo 源码
            </span>
          </div>
          <span className="mono-text text-xs text-gray-500">
            {showLeo ? "▲ 折叠" : "▼ 展开"}
          </span>
        </button>

        {showLeo && (
          <div className="border-t border-gray-700/40">
            <div className="flex items-center gap-2 px-4 py-2 bg-black/40 border-b border-gray-700/30">
              <div className="w-3 h-3 rounded-full bg-red-500/70" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
              <div className="w-3 h-3 rounded-full bg-green-500/70" />
              <span className="mono-text text-[10px] text-gray-500 ml-2">
                fitness_oracle/build/main.aleo
              </span>
            </div>
            <pre className="p-4 text-[10px] mono-text text-[#00ffaa]/80 leading-relaxed overflow-x-auto whitespace-pre bg-black/20 max-h-80 overflow-y-auto">
              {result.leoCode}
            </pre>
          </div>
        )}
      </div>

      <div className="text-center py-2">
        <div className="mono-text text-[10px] text-gray-600">
          Powered by <span className="text-[#00ffaa]">Aleo Network</span> · Built with{" "}
          <span className="text-purple-400">Leo Language</span>
        </div>
        <div className="mono-text text-[9px] text-gray-700 mt-1">
          Privacy by Default · Zero-Knowledge · Trustless
        </div>
      </div>
    </div>
  );
}
