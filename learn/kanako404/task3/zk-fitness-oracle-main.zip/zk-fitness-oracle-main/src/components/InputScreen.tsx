import { useState } from "react";
import type { FitnessInput, AleoAccount } from "../leoRuntime";

interface Props {
  onCompute: (input: FitnessInput) => void;
  account: AleoAccount | null;
  sdkReady: boolean | null;
}

export default function InputScreen({ onCompute, account, sdkReady }: Props) {
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [birthYear, setBirthYear] = useState("");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [focused, setFocused] = useState<string | null>(null);

  const currentYear = new Date().getFullYear();

  const validate = () => {
    const errs: Record<string, string> = {};
    const h = parseFloat(height);
    const w = parseFloat(weight);
    const y = parseInt(birthYear);

    if (!height || isNaN(h) || h < 100 || h > 250)
      errs.height = "身高应在 100–250 cm 之间";
    if (!weight || isNaN(w) || w < 20 || w > 300)
      errs.weight = "体重应在 20–300 kg 之间";
    if (!birthYear || isNaN(y) || y < 1920 || y > currentYear - 10)
      errs.birthYear = `出生年份应在 1920–${currentYear - 10} 之间`;

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onCompute({
      heightCm: Math.round(parseFloat(height)),
      weightKg: Math.round(parseFloat(weight)),
      birthYear: parseInt(birthYear),
      gender,
    });
  };

  const bmi =
    height && weight
      ? (() => {
          const h = parseFloat(height) / 100;
          const w = parseFloat(weight);
          if (h > 0 && w > 0) return (w / (h * h)).toFixed(1);
          return null;
        })()
      : null;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      <div className="text-center mb-8">
        <div className="pixel-text text-[8px] text-[#00ffaa]/50 mb-3 tracking-widest">
          — CHARACTER STATS ENTRY —
        </div>
        <h2 className="pixel-text text-lg md:text-xl text-white mb-2">
          输入你的<span className="text-[#00ffaa] glow-green">角色属性</span>
        </h2>
        <p className="mono-text text-xs text-gray-400 max-w-sm mx-auto">
          所有数据作为 <span className="text-purple-400">private</span> 输入传入 Leo 电路，
          不会泄露给任何第三方
        </p>
      </div>

      {/* Mode indicator */}
      <div className="flex items-center gap-3 mb-8 px-4 py-2 rounded-full bg-purple-900/20 border border-purple-500/30">
        <span className="text-purple-400 text-sm">
          {sdkReady ? "⚡" : "🔒"}
        </span>
        <span className="mono-text text-xs text-purple-300">
          {sdkReady
            ? "ZK Mode · snarkVM WASM · Real Proof"
            : "Local Mode · Leo Circuit Mirror"}
        </span>
        {account && (
          <span className="mono-text text-[10px] text-green-400">
            · {account.address.slice(0, 8)}...
          </span>
        )}
      </div>

      <div className="card-rpg w-full max-w-lg rounded-xl p-6 md:p-8 space-y-6">
        {/* Leo source preview */}
        <div className="bg-black/40 rounded-lg p-3 border-l-2 border-[#00ffaa]/40">
          <pre className="mono-text text-[10px] text-[#00ffaa]/60 leading-relaxed whitespace-pre-wrap">
{`// fitness_oracle.aleo
fn compute_fitness(
  private height_cm: u32,  ← 你的输入
  private weight_kg: u32,  ← 你的输入
  private birth_year: u32, ← 你的输入
  private gender: u8,      ← 你的输入
  public  current_year: u32,
) -> FitnessData { ... }`}
          </pre>
        </div>

        {/* Gender */}
        <div>
          <label className="pixel-text text-[9px] text-[#00ffaa] mb-3 block">
            ◆ 性别 / GENDER <span className="text-purple-400">(private u8)</span>
          </label>
          <div className="grid grid-cols-2 gap-3">
            {(["male", "female"] as const).map((g) => (
              <button
                key={g}
                onClick={() => setGender(g)}
                className={`btn-rpg py-3 px-4 rounded-lg border transition-all duration-200 mono-text text-sm flex items-center justify-center gap-2 ${
                  gender === g
                    ? "border-[#00ffaa] bg-[#00ffaa]/15 text-[#00ffaa] shadow-[0_0_15px_rgba(0,255,170,0.3)]"
                    : "border-gray-600 bg-black/20 text-gray-400 hover:border-gray-400"
                }`}
              >
                <span className="text-lg">{g === "male" ? "♂" : "♀"}</span>
                <span className="pixel-text text-[9px]">
                  {g === "male" ? "男性" : "女性"}
                </span>
              </button>
            ))}
          </div>
        </div>

        <InputField
          label="身高 / HEIGHT (cm)"
          typeLabel="private u32"
          placeholder="例：175"
          value={height}
          onChange={setHeight}
          error={errors.height}
          isFocused={focused === "height"}
          onFocus={() => setFocused("height")}
          onBlur={() => setFocused(null)}
          hint="100–250"
          icon="📏"
          type="number"
        />

        <InputField
          label="体重 / WEIGHT (kg)"
          typeLabel="private u32"
          placeholder="例：70"
          value={weight}
          onChange={setWeight}
          error={errors.weight}
          isFocused={focused === "weight"}
          onFocus={() => setFocused("weight")}
          onBlur={() => setFocused(null)}
          hint="20–300"
          icon="⚖️"
          type="number"
        />

        <InputField
          label="出生年份 / BIRTH YEAR"
          typeLabel="private u32"
          placeholder={`例：${currentYear - 25}`}
          value={birthYear}
          onChange={setBirthYear}
          error={errors.birthYear}
          isFocused={focused === "birthYear"}
          onFocus={() => setFocused("birthYear")}
          onBlur={() => setFocused(null)}
          hint={`1920–${currentYear - 10}`}
          icon="📅"
          type="number"
        />

        {bmi && (
          <div className="flex items-center gap-3 px-4 py-3 rounded-lg bg-[#00ffaa]/5 border border-[#00ffaa]/20 fade-in-up">
            <span className="text-xl">⚡</span>
            <div>
              <div className="mono-text text-[10px] text-gray-400">
                实时 BMI 预览
              </div>
              <div className="orbitron text-lg text-[#00ffaa] glow-green">
                {bmi}
              </div>
            </div>
            <div className="ml-auto mono-text text-[10px] text-gray-500">
              {parseFloat(bmi) < 18.5
                ? "偏轻"
                : parseFloat(bmi) < 25
                  ? "正常"
                  : parseFloat(bmi) < 30
                    ? "偏重"
                    : "肥胖"}
            </div>
          </div>
        )}

        <button
          onClick={handleSubmit}
          className="btn-rpg w-full py-4 pixel-text text-[10px] md:text-xs bg-gradient-to-r from-[#00ffaa]/20 to-[#00ddff]/20 border-2 border-[#00ffaa] text-[#00ffaa] rounded-lg hover:bg-[#00ffaa]/30 transition-all duration-200 glow-green mt-2"
        >
          ⚡ 执行 LEO 零知识计算
        </button>

        <p className="mono-text text-[10px] text-gray-600 text-center">
          🔒 所有 private 输入仅在本地电路中使用 · 零数据外传
        </p>
      </div>

      <div className="mt-6 mono-text text-[10px] text-gray-600 text-center max-w-sm">
        fitness_oracle.aleo · {sdkReady ? "snarkVM WASM" : "Local Mirror"} · Leo ZK Circuit
      </div>
    </div>
  );
}

interface InputFieldProps {
  label: string;
  typeLabel: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  error?: string;
  isFocused: boolean;
  onFocus: () => void;
  onBlur: () => void;
  hint: string;
  icon: string;
  type?: string;
}

function InputField({
  label,
  typeLabel,
  placeholder,
  value,
  onChange,
  error,
  isFocused,
  onFocus,
  onBlur,
  hint,
  icon,
  type = "text",
}: InputFieldProps) {
  return (
    <div>
      <label className="pixel-text text-[9px] text-[#00ffaa] mb-2 flex items-center gap-2">
        <span>{icon}</span> {label}{" "}
        <span className="text-purple-400 font-normal">({typeLabel})</span>
      </label>
      <div
        className={`relative rounded-lg border transition-all duration-200 overflow-hidden ${
          error
            ? "border-red-500/70 bg-red-900/10"
            : isFocused
              ? "border-[#00ffaa]/70 bg-[#00ffaa]/5 shadow-[0_0_15px_rgba(0,255,170,0.15)]"
              : "border-gray-600/50 bg-black/30 hover:border-gray-400/50"
        }`}
      >
        {isFocused && (
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#00ffaa] to-transparent" />
        )}
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={onFocus}
          onBlur={onBlur}
          className="w-full px-4 py-3 bg-transparent mono-text text-sm text-white placeholder-gray-600 outline-none"
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2 mono-text text-[10px] text-gray-600">
          {hint}
        </div>
      </div>
      {error && (
        <p className="mt-1 mono-text text-[10px] text-red-400 flex items-center gap-1">
          <span>⚠</span> {error}
        </p>
      )}
    </div>
  );
}
