import { Component, type ReactNode } from "react";

interface Props {
  children: ReactNode;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  message: string;
}

export default class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, message: "" };
  }

  static getDerivedStateFromError(error: unknown): State {
    return {
      hasError: true,
      message: error instanceof Error ? error.message : String(error),
    };
  }

  componentDidCatch(error: unknown) {
    console.error("[ErrorBoundary]", error);
  }

  handleReset = () => {
    this.setState({ hasError: false, message: "" });
    this.props.onReset?.();
  };

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12 text-center">
        <div className="card-rpg rounded-xl p-8 max-w-md w-full">
          <div className="text-5xl mb-4">⚠️</div>
          <div className="pixel-text text-sm text-red-400 mb-3">
            渲染出现异常
          </div>
          <div className="mono-text text-[11px] text-gray-400 leading-relaxed mb-6 break-words">
            {this.state.message || "未知错误"}
          </div>
          <button
            onClick={this.handleReset}
            className="btn-rpg pixel-text text-[10px] px-6 py-3 border-2 border-[#00ffaa] text-[#00ffaa] rounded-lg hover:bg-[#00ffaa]/20 transition-all"
          >
            ↩ 返回重试 / RESET
          </button>
        </div>
      </div>
    );
  }
}
