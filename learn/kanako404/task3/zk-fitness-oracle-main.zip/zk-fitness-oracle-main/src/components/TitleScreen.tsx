import { useState, useEffect } from "react";
import type { AleoAccount } from "../leoRuntime";

interface Props {
  onStart: () => void;
  account: AleoAccount | null;
  sdkReady: boolean | null;
  onGenerateAccount: () => Promise<void>;
  onImportAccount: (pk: string) => Promise<void>;
  walletInstalled: boolean;
  walletConnected: boolean;
  onConnectWallet: () => Promise<void>;
  onDisconnectWallet: () => Promise<void>;
}

export default function TitleScreen({
  onStart,
  account,
  sdkReady,
  onGenerateAccount,
  onImportAccount,
  walletInstalled,
  walletConnected,
  onConnectWallet,
  onDisconnectWallet,
}: Props) {
  const [blink, setBlink] = useState(true);
  const [typedText, setTypedText] = useState("");
  const [showImport, setShowImport] = useState(false);
  const [importKey, setImportKey] = useState("");
  const [importError, setImportError] = useState("");
  const [generating, setGenerating] = useState(false);
  const [walletError, setWalletError] = useState("");

  const fullText =
    sdkReady === null
      ? "> 正在初始化 Aleo snarkVM WASM 环境..."
      : sdkReady
        ? "> Aleo snarkVM 已就绪 · 零知识证明引擎在线 · 本地隐私计算可用"
        : "> 本地计算模式已就绪 · Leo 电路逻辑镜像执行";

  useEffect(() => {
    let i = 0;
    setTypedText("");
    const t = setInterval(() => {
      setTypedText(fullText.slice(0, i + 1));
      i++;
      if (i >= fullText.length) clearInterval(t);
    }, 30);
    return () => clearInterval(t);
  }, [fullText]);

  useEffect(() => {
    const t = setInterval(() => setBlink((v) => !v), 600);
    return () => clearInterval(t);
  }, []);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      await onGenerateAccount();
    } finally {
      setGenerating(false);
    }
  };

  const handleImport = async () => {
    if (!importKey.trim()) return;
    setImportError("");
    try {
      await onImportAccount(importKey.trim());
      setShowImport(false);
      setImportKey("");
    } catch {
      setImportError("无效的私钥格式");
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      {/* SDK status badge */}
      <div className="mb-8 flex items-center gap-2 px-4 py-2 rounded-full border border-purple-500/40 bg-purple-900/20 backdrop-blur-sm">
        <div
          className={`w-2 h-2 rounded-full ${sdkReady === null ? "bg-yellow-400 animate-pulse" : sdkReady ? "bg-green-400 animate-pulse" : "bg-orange-400"}`}
        />
        <span className="mono-text text-purple-300 text-xs">
          {sdkReady === null
            ? "ALEO WASM · LOADING..."
            : sdkReady
              ? "ALEO SNARKVM · READY"
              : "LOCAL MODE · ACTIVE"}
        </span>
        <div
          className={`w-2 h-2 rounded-full ${sdkReady ? "bg-green-400 animate-pulse" : "bg-orange-400"}`}
        />
      </div>

      {/* Main title */}
      <div className="text-center mb-8">
        <div className="pixel-text text-[10px] text-[#00ffaa]/60 mb-4 tracking-widest">
          ★ PRIVACY FITNESS ORACLE ★
        </div>
        <h1
          className="pixel-text text-2xl md:text-4xl text-[#00ffaa] glow-green leading-relaxed mb-2"
          style={{ animation: "glitch 8s ease-in-out infinite" }}
        >
          ZK FITNESS
        </h1>
        <h1 className="pixel-text text-2xl md:text-4xl text-white leading-relaxed">
          ORACLE
        </h1>
        <div className="mt-4 h-px bg-gradient-to-r from-transparent via-[#00ffaa]/60 to-transparent" />
        <p className="mt-4 orbitron text-sm text-[#00ffaa]/70 tracking-widest">
          零知识证明 · 隐私计算 · 健身智慧
        </p>
      </div>

      {/* Hexagon icon */}
      <div className="relative mb-10">
        <div className="w-32 h-32 md:w-40 md:h-40 relative">
          <svg
            viewBox="0 0 100 100"
            className="absolute inset-0 w-full h-full"
            style={{ animation: "rotateSlow 20s linear infinite" }}
          >
            <polygon
              points="50,5 95,27.5 95,72.5 50,95 5,72.5 5,27.5"
              fill="none"
              stroke="rgba(0,255,170,0.4)"
              strokeWidth="1.5"
              strokeDasharray="4 2"
            />
          </svg>
          <svg
            viewBox="0 0 100 100"
            className="absolute inset-0 w-full h-full"
            style={{ animation: "rotateSlow 15s linear infinite reverse" }}
          >
            <polygon
              points="50,12 88,31 88,69 50,88 12,69 12,31"
              fill="none"
              stroke="rgba(168,85,247,0.3)"
              strokeWidth="1"
              strokeDasharray="2 4"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-5xl md:text-6xl" style={{ animation: "float 4s ease-in-out infinite" }}>
              🧬
            </div>
          </div>
        </div>
      </div>

      {/* Typewriter text */}
      <div className="w-full max-w-lg mb-6 px-4 py-3 rounded border border-[#00ffaa]/20 bg-black/40 backdrop-blur-sm">
        <p className="mono-text text-[11px] text-[#00ffaa]/80 leading-relaxed min-h-[36px]">
          {typedText}
          <span
            className={`inline-block w-2 h-3 bg-[#00ffaa] ml-1 ${blink ? "opacity-100" : "opacity-0"} transition-opacity`}
          />
        </p>
      </div>

      {/* Wallet section */}
      <div className="w-full max-w-lg mb-8">
        {account ? (
          <div className="card-rpg rounded-xl p-4 mb-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="pixel-text text-[8px] text-[#00ffaa]">
                  {walletConnected ? "LEO WALLET CONNECTED" : "ALEO ACCOUNT ACTIVE"}
                </span>
              </div>
              {walletConnected && (
                <button
                  onClick={onDisconnectWallet}
                  className="mono-text text-[10px] text-red-400/70 hover:text-red-400 transition-colors"
                >
                  断开连接
                </button>
              )}
            </div>
            <div className="space-y-1">
              <div className="mono-text text-[10px] text-gray-400">
                <span className="text-gray-600">Address: </span>
                <span className="text-[#00ffaa]">
                  {account.address.slice(0, 16)}...{account.address.slice(-8)}
                </span>
              </div>
              {account.viewKey && (
                <div className="mono-text text-[10px] text-gray-400">
                  <span className="text-gray-600">View Key: </span>
                  <span className="text-purple-400">
                    {account.viewKey.slice(0, 12)}...
                  </span>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {/* Leo Wallet — primary connection method */}
            {walletInstalled ? (
              <button
                onClick={async () => {
                  setWalletError("");
                  try { await onConnectWallet(); } catch (e: any) { setWalletError(e.message); }
                }}
                className="btn-rpg w-full py-3 px-4 rounded-lg border-2 border-[#00ffaa]/60 bg-[#00ffaa]/10 text-[#00ffaa] mono-text text-xs hover:bg-[#00ffaa]/20 transition-all flex items-center justify-center gap-2"
              >
                <span className="text-base">🦁</span> 连接 Leo Wallet
              </button>
            ) : (
              <a
                href="https://www.leo.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-rpg w-full py-3 px-4 rounded-lg border border-gray-600/50 bg-gray-900/30 text-gray-400 mono-text text-xs hover:bg-gray-900/50 transition-all flex items-center justify-center gap-2"
              >
                <span className="text-base">🦁</span> 安装 Leo Wallet 浏览器插件
                <span className="text-[10px] text-gray-600">↗</span>
              </a>
            )}
            {walletError && (
              <p className="mono-text text-[10px] text-red-400 text-center">{walletError}</p>
            )}

            {/* Divider */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-gray-700/50" />
              <span className="mono-text text-[10px] text-gray-600">或使用内置账户</span>
              <div className="flex-1 h-px bg-gray-700/50" />
            </div>

            {/* SDK account generation (fallback) */}
            {sdkReady ? (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={handleGenerate}
                    disabled={generating}
                    className="btn-rpg py-3 px-4 rounded-lg border border-[#00ffaa]/30 bg-[#00ffaa]/5 text-[#00ffaa]/80 mono-text text-xs hover:bg-[#00ffaa]/15 transition-all disabled:opacity-50"
                  >
                    {generating ? "生成中..." : "🔑 生成新账户"}
                  </button>
                  <button
                    onClick={() => setShowImport(!showImport)}
                    className="btn-rpg py-3 px-4 rounded-lg border border-purple-500/30 bg-purple-900/5 text-purple-300/80 mono-text text-xs hover:bg-purple-900/15 transition-all"
                  >
                    📥 导入私钥
                  </button>
                </div>
                {showImport && (
                  <div className="card-rpg rounded-lg p-4 space-y-2 fade-in-up">
                    <input
                      type="password"
                      placeholder="APrivateKey1..."
                      value={importKey}
                      onChange={(e) => setImportKey(e.target.value)}
                      className="w-full px-3 py-2 bg-black/50 border border-gray-600/50 rounded mono-text text-xs text-white placeholder-gray-600 outline-none focus:border-purple-400/50"
                    />
                    {importError && (
                      <p className="mono-text text-[10px] text-red-400">{importError}</p>
                    )}
                    <button
                      onClick={handleImport}
                      className="w-full py-2 rounded border border-purple-500/50 bg-purple-900/20 text-purple-300 mono-text text-xs hover:bg-purple-900/30"
                    >
                      确认导入
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center mono-text text-[10px] text-gray-500">
                本地计算模式 · 无需钱包 · Leo 电路逻辑镜像执行
              </div>
            )}
          </div>
        )}
      </div>

      {/* Feature list */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 max-w-2xl w-full mb-10 px-4">
        {[
          {
            icon: "🔒",
            title: "隐私保护",
            desc: "身体数据作为 private 输入，ZK 证明保证数据不泄露",
          },
          {
            icon: "⚡",
            title: "Leo 电路计算",
            desc: "BMI · BMR · 体脂率 · 健康分 由 Aleo 程序计算",
          },
          {
            icon: "🎮",
            title: "RPG 任务系统",
            desc: "将健身目标转化为游戏任务，获得 XP 奖励",
          },
        ].map((f) => (
          <div key={f.title} className="card-rpg rounded-lg p-3 text-center">
            <div className="text-2xl mb-2">{f.icon}</div>
            <div className="pixel-text text-[8px] text-[#00ffaa] mb-1">{f.title}</div>
            <div className="mono-text text-[10px] text-gray-400 leading-relaxed">{f.desc}</div>
          </div>
        ))}
      </div>

      {/* Start button */}
      <button
        onClick={onStart}
        className="btn-rpg pixel-text text-xs md:text-sm px-8 py-4 bg-gradient-to-r from-[#00ffaa]/20 to-[#00ddff]/20 border-2 border-[#00ffaa] text-[#00ffaa] rounded hover:bg-[#00ffaa]/30 hover:scale-105 transition-all duration-200 glow-green"
        style={{ animation: "pulse-green 2s ease-in-out infinite" }}
      >
        ▶ PRESS START
      </button>

      <div className="mt-6 mono-text text-[10px] text-gray-600 text-center max-w-sm px-4">
        Powered by{" "}
        <span className="text-[#00ffaa]/60">Leo Language</span> ·{" "}
        <span className="text-purple-400/60">Aleo Network</span> ·{" "}
        <span className="text-yellow-400/60">snarkVM</span>
      </div>

      <div className="mt-8 flex items-center gap-4">
        {["◈", "◆", "◈"].map((s, i) => (
          <span key={i} className="text-[#00ffaa]/30 text-xs pixel-text">
            {s}
          </span>
        ))}
      </div>
    </div>
  );
}
