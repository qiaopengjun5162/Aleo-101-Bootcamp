# 部署指南 — ZK Fitness Oracle

本文档说明如何在**本地测试网**和**Aleo 公共测试网**上部署 ZK Fitness Oracle 程序，并记录了实际的测试网部署结果。

---

## 测试网部署记录（已完成）

> 以下为 2026-06-07 实际完成的测试网部署与链上交互记录。

### 合约信息

| 项目 | 值 |
|------|------|
| **程序 ID（合约地址）** | `fitness_rpg_6576.aleo` |
| **网络** | Aleo Testnet |
| **共识版本** | Consensus V15 |
| **部署者地址** | `aleo100pc57pjxu7lz6efzyd9jku55mtcld57zqge9gl2ugyat32tdg9swydz04` |
| **程序大小** | 1.67 KB / 500 KB |
| **ZK 电路复杂度** | 24,862 variables / 18,241 constraints |

### 部署交易

| 项目 | 值 |
|------|------|
| **部署交易 ID** | `at1j9qhxu4mgrr2v5uk9x53v6pzr7fr3s4tvsjsksk8nkpywud8gsgqtqn2s8` |
| **Fee 交易 ID** | `at1c8j92nn5galpufyc52t367xj2g275k7fdmwwj4f6rkgmw7fancxs36lpyj` |
| **交易状态** | ✅ Confirmed |
| **部署总费用** | 2.639103 credits |
| ├ 存储费 | 1.594000 credits |
| ├ 合成费 | 0.043103 credits |
| ├ 命名空间费 | 1.000000 credits |
| └ 构造函数费 | 0.002000 credits |
| **Explorer 链接** | [查看部署交易](https://testnet.explorer.provable.com/transaction/at1j9qhxu4mgrr2v5uk9x53v6pzr7fr3s4tvsjsksk8nkpywud8gsgqtqn2s8) |

### 链上交互交易

| 项目 | 值 |
|------|------|
| **执行交易 ID** | `at14xfnxwkhmskz3c8xk8stvg0pty68nqg9q7uz9rdxwvr78u7sfggq645fpd` |
| **Fee 交易 ID** | `at1halxdn50qcpvnsf4dfcrp2hjdj48nyfe8500slypzdd4mmfyyqgqx7y8xc` |
| **交易状态** | ✅ Confirmed |
| **执行费用** | 0.001638 credits |
| **调用函数** | `compute_fitness` |
| **输入参数** | `175u32 70u32 1995u32 1u8 2026u32` |
| **输入含义** | 身高 175cm, 体重 70kg, 1995 年生, 男性, 当前 2026 年 |
| **Explorer 链接** | [查看执行交易](https://testnet.explorer.provable.com/transaction/at14xfnxwkhmskz3c8xk8stvg0pty68nqg9q7uz9rdxwvr78u7sfggq645fpd) |

### 链上交互输出（ZK 证明保护下的计算结果）

```
{
  bmi_x100:      2285    → BMI = 22.85（正常体重）
  bmr:           1600    → 基础代谢率 1600 kcal/天
  body_fat_x10:  183     → 体脂率 18.3%
  fitness_class: 1       → 正常体型（0=偏瘦 1=正常 2=超重 3=肥胖）
  health_score:  99      → 健康评分 99/100
  age:           31      → 年龄 31 岁
}
```

> **隐私保护**：以上所有私密输入（身高、体重、出生年份、性别）在链上完全不可见。任何人可以验证计算结果的正确性，但无法推断出原始数据。

### 账户余额变化

| 时间点 | 余额 |
|--------|------|
| 部署前 | 40.000000 credits |
| 部署+执行后 | 37.359259 credits |
| 总消耗 | 2.640741 credits |

---

## 前置要求

| 工具 | 安装方式 | 验证命令 |
|------|----------|----------|
| **Leo CLI 4.x** | `cargo install leo-lang` | `leo --version` |
| **Docker**（仅本地网络需要） | [Docker Desktop](https://www.docker.com/products/docker-desktop/) | `docker --version` |
| **Node.js 18+** | [nodejs.org](https://nodejs.org/) | `node --version` |

---

## 一、编译 Leo 程序

```bash
cd fitness_oracle
leo build --network testnet
```

成功输出：

```
Leo ✅ Compiled 'fitness_rpg_6576.aleo' into Aleo instructions.
Leo ✅ Generated ABI for program 'fitness_rpg_6576.aleo'.
```

> **重要**：Leo 4.x 要求所有程序必须包含 `@noupgrade constructor() {}`，否则 Consensus V9+ 的网络会拒绝部署。

### 验证程序逻辑

使用 `leo run` 在本地 VM 中测试（不需要网络）：

```bash
# 正常男性：175cm, 70kg, 1995年出生, 男(1), 当前2026年
leo run compute_fitness 175u32 70u32 1995u32 1u8 2026u32

# 预期输出：
# bmi_x100: 2285u32, bmr: 1600u32, fitness_class: 1u8, health_score: 99u8

# 更多测试用例
leo run compute_fitness 180u32 50u32 1998u32 1u8 2026u32   # 偏瘦
leo run compute_fitness 170u32 100u32 1990u32 1u8 2026u32  # 肥胖
leo run compute_fitness 165u32 55u32 2000u32 0u8 2026u32   # 正常女性
```

---

## 二、本地测试网部署

### 步骤 1：启动 4 节点 Devnet

Aleo 的 `--dev` 模式需要 4 个 validator 达成 BFT 共识：

```bash
docker run -d \
  --name aleo-devnet \
  -p 3030:3030 \
  -v ./devnet/start-devnet.sh:/start-devnet.sh \
  --entrypoint /bin/bash \
  aleohq/snarkos:latest \
  /start-devnet.sh
```

### 步骤 2：等待出块

```bash
docker logs -f aleo-devnet 2>&1 | grep "Advanced"
```

看到 `Advanced to block X` 即可继续。

### 步骤 3：部署程序

```bash
cd fitness_oracle
leo deploy \
  --endpoint "http://localhost:3030" \
  --network mainnet \
  --private-key "<DEV_PRIVATE_KEY>" \
  --yes --broadcast
```

> **⚠️ 密钥说明**：`<DEV_PRIVATE_KEY>` 替换为 snarkOS `--dev 0` 内置的开发密钥（可在启动日志中找到）。仅用于本地开发，**切勿在生产环境使用**。

---

## 三、公共测试网部署

### 步骤 1：准备账户和资金

1. 安装 [Leo Wallet](https://www.leo.app/) 浏览器插件
2. 创建新钱包，切换到 **Testnet** 网络
3. 前往 [Aleo Faucet](https://faucet.aleo.org/) 领取测试币（部署约需 3 credits）
4. 导出私钥（Leo Wallet → 设置 → 导出私钥）

### 步骤 2：确保程序名唯一

测试网上程序名不可重复。如需修改：

```bash
# 修改 fitness_oracle/program.json 中的 program 字段
# 同步修改 fitness_oracle/src/main.leo 中的 program 声明
```

### 步骤 3：部署到公共测试网

```bash
cd fitness_oracle
leo deploy \
  --endpoint "https://api.explorer.provable.com/v1" \
  --network testnet \
  --private-key "<你的测试网私钥>" \
  --yes --broadcast
```

部署成功输出示例：

```
📦 Creating deployment transaction for 'fitness_rpg_6576.aleo'...
📡 Broadcasting deployment for fitness_rpg_6576.aleo...
✉️ Broadcasted transaction with:
  - transaction ID: 'at1j9qhxu4mgrr2v5uk9x53v6pzr7fr3s4tvsjsksk8nkpywud8gsgqtqn2s8'
✅ Deployment confirmed!
```

### 步骤 4：验证部署

```bash
# 通过 API 查询
curl "https://api.explorer.provable.com/v1/testnet/program/fitness_rpg_6576.aleo"

# 或访问 Explorer
# https://testnet.explorer.provable.com/program/fitness_rpg_6576.aleo
```

### 步骤 5：链上交互（执行 ZK 计算）

```bash
cd fitness_oracle

# 执行隐私健康计算（所有私密输入在链上不可见）
leo execute compute_fitness \
  175u32 70u32 1995u32 1u8 2026u32 \
  --endpoint "https://api.explorer.provable.com/v1" \
  --network testnet \
  --private-key "<你的测试网私钥>" \
  --yes --broadcast
```

执行成功输出示例：

```
⚙️ Executing fitness_rpg_6576.aleo/compute_fitness...
➡️  Output
 • {
  bmi_x100: 2285u32,
  bmr: 1600u32,
  body_fat_x10: 183u32,
  fitness_class: 1u8,
  health_score: 99u8,
  age: 31u8
}
📡 Broadcasting execution for fitness_rpg_6576.aleo...
✉️ Broadcasted transaction with:
  - transaction ID: 'at14xfnxwkhmskz3c8xk8stvg0pty68nqg9q7uz9rdxwvr78u7sfggq645fpd'
✅ Execution confirmed!
```

### 步骤 6：查询链上交易详情

```bash
# 查询部署交易
curl "https://api.explorer.provable.com/v1/testnet/transaction/at1j9qhxu4mgrr2v5uk9x53v6pzr7fr3s4tvsjsksk8nkpywud8gsgqtqn2s8"

# 查询执行交易
curl "https://api.explorer.provable.com/v1/testnet/transaction/at14xfnxwkhmskz3c8xk8stvg0pty68nqg9q7uz9rdxwvr78u7sfggq645fpd"

# 查询账户余额
curl "https://api.explorer.provable.com/v1/testnet/program/credits.aleo/mapping/account/<你的地址>"
```

---

## 四、前端连接已部署的程序

前端默认通过 `@provablehq/sdk` 在浏览器内本地执行 Leo 程序。连接链上程序：

```typescript
// src/aleo/program.ts
export const NETWORK_ENDPOINT = "https://api.explorer.provable.com/v1";
```

安装并连接 Leo Wallet 浏览器插件后，即可在前端发起链上交互。

---

## 五、交互测试脚本

项目提供了自动化测试脚本：

```bash
# Bash (Linux/macOS)
export PRIVATE_KEY="<你的私钥>"
chmod +x scripts/testnet_interaction_test.sh
./scripts/testnet_interaction_test.sh

# PowerShell (Windows)
$env:PRIVATE_KEY = "<你的私钥>"
.\scripts\deploy_and_test.ps1
```

脚本会自动完成：编译 → 本地测试 → 部署 → 链上执行 → 打印所有交易信息。

---

## 六、测试环境清理

### 1. 停止前端开发服务器

在 `npm run dev` 终端按 `Ctrl + C`。

### 2. 停止并清理本地 Devnet

```bash
docker stop aleo-devnet        # 停止（保留数据）
docker rm -f aleo-devnet       # 删除容器
docker rmi aleohq/snarkos:latest  # 删除镜像（~1.5 GB）
```

### 3. 清理编译缓存

```bash
rm -rf fitness_oracle/build/
rm -rf fitness_oracle/outputs/
```

### 4. 资源占用参考

| 组件 | 运行时内存 | 磁盘占用 |
|------|-----------|---------|
| Docker snarkOS（4 节点） | ~2-4 GB | 镜像 ~1.5 GB + 链数据 |
| `npm run dev`（Vite） | ~200 MB | — |
| `leo build / run` | 峰值 ~500 MB | `build/` ~10 KB |
| `node_modules/` | — | ~300 MB |

---

## 常见问题

### Q: 部署失败提示 "must contain a constructor"？

Leo 4.x / Consensus V9+ 要求所有程序必须包含构造函数：

```leo
program your_program.aleo {
    @noupgrade
    constructor() {}

    fn your_function(...) -> ... { ... }
}
```

### Q: 余额不足？

- 本地网络：使用 `--dev 0` 内置密钥（有预分配资金）
- 公共测试网：前往 [Aleo Faucet](https://faucet.aleo.org/) 领取测试币

### Q: 程序名已被占用？

修改 `program.json` 中的 `program` 字段和 `main.leo` 中的 `program` 声明，使用唯一名称。

### Q: `leo deploy` 超时？

部署需要生成 ZK 证明，通常需要 20-40 秒。如反复超时，检查网络连接或尝试不同的 endpoint。
