#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# ZK Fitness Oracle — Testnet Interaction Test Script
# ─────────────────────────────────────────────────────────────
#
# This script verifies the deployed program and runs on-chain interactions.
#
# Usage:
#   export PRIVATE_KEY="APrivateKey1..."
#   chmod +x scripts/testnet_interaction_test.sh
#   ./scripts/testnet_interaction_test.sh

set -euo pipefail

PROGRAM="fitness_rpg_6576.aleo"
FUNCTION="compute_fitness"
ENDPOINT="${ENDPOINT:-https://api.explorer.provable.com/v1}"
NETWORK="${NETWORK:-testnet}"
PRIVATE_KEY="${PRIVATE_KEY:-}"
DEPLOY_TX="at1j9qhxu4mgrr2v5uk9x53v6pzr7fr3s4tvsjsksk8nkpywud8gsgqtqn2s8"
EXEC_TX="at14xfnxwkhmskz3c8xk8stvg0pty68nqg9q7uz9rdxwvr78u7sfggq645fpd"

G='\033[0;32m'; Y='\033[1;33m'; C='\033[0;36m'; R='\033[0;31m'; N='\033[0m'

echo -e "${C}══════════════════════════════════════════════════════════${N}"
echo -e "${C}   ZK Fitness Oracle — Testnet On-chain Info & Test${N}"
echo -e "${C}══════════════════════════════════════════════════════════${N}"
echo ""

# ─── 1. Print deployed contract info ─────────────────────
echo -e "${Y}[1] Deployed Contract Information${N}"
echo -e "  Program ID (Contract Address): ${G}${PROGRAM}${N}"
echo -e "  Network:                       ${NETWORK}"
echo -e "  Endpoint:                      ${ENDPOINT}"
echo -e "  Explorer URL:                  ${C}https://testnet.explorer.provable.com/program/${PROGRAM}${N}"
echo ""

# ─── 2. Print deployment transaction ─────────────────────
echo -e "${Y}[2] Deployment Transaction${N}"
echo -e "  Transaction ID:  ${G}${DEPLOY_TX}${N}"
echo -e "  Explorer URL:    ${C}https://testnet.explorer.provable.com/transaction/${DEPLOY_TX}${N}"
echo -e "  Total Fee:       2.639103 credits"
echo -e "    ├─ Storage:    1.594000 credits"
echo -e "    ├─ Synthesis:  0.043103 credits"
echo -e "    ├─ Namespace:  1.000000 credits"
echo -e "    └─ Constructor:0.002000 credits"
echo ""

# ─── 3. Print execution transaction ──────────────────────
echo -e "${Y}[3] On-chain Execution Transaction${N}"
echo -e "  Transaction ID:  ${G}${EXEC_TX}${N}"
echo -e "  Explorer URL:    ${C}https://testnet.explorer.provable.com/transaction/${EXEC_TX}${N}"
echo -e "  Function:        ${FUNCTION}"
echo -e "  Inputs:          175u32 70u32 1995u32 1u8 2026u32"
echo -e "  Input Meaning:   height=175cm, weight=70kg, birth=1995, male, year=2026"
echo -e "  Execution Fee:   0.001638 credits"
echo -e "  Output:"
echo -e "    ${G}{"
echo -e "      bmi_x100:      2285    (BMI = 22.85)"
echo -e "      bmr:           1600    (Base Metabolic Rate)"
echo -e "      body_fat_x10:  183     (Body Fat = 18.3%)"
echo -e "      fitness_class: 1       (Normal)"
echo -e "      health_score:  99      (out of 100)"
echo -e "      age:           31"
echo -e "    }${N}"
echo ""

# ─── 4. Verify program on-chain via API ──────────────────
echo -e "${Y}[4] Verifying program exists on-chain...${N}"
STATUS=$(curl -s -o /dev/null -w "%{http_code}" "${ENDPOINT}/${NETWORK}/program/${PROGRAM}" 2>/dev/null || echo "000")
if [ "$STATUS" = "200" ]; then
    echo -e "  ${G}✅ Program verified on testnet!${N}"
else
    echo -e "  ${R}⚠ API returned status $STATUS (may be temporary)${N}"
fi
echo ""

# ─── 5. Check account balance ────────────────────────────
echo -e "${Y}[5] Account Balance${N}"
ADDR="aleo100pc57pjxu7lz6efzyd9jku55mtcld57zqge9gl2ugyat32tdg9swydz04"
echo -e "  Address: ${ADDR}"
BAL=$(curl -s "${ENDPOINT}/${NETWORK}/program/credits.aleo/mapping/account/${ADDR}" 2>/dev/null || echo "\"unknown\"")
echo -e "  Balance: ${G}${BAL}${N}"
echo ""

# ─── 6. Run additional on-chain test (if key provided) ───
if [ -n "$PRIVATE_KEY" ]; then
    echo -e "${Y}[6] Running additional on-chain interaction...${N}"
    echo -e "  Test case: Female, 160cm, 55kg, born 2000, year 2026"
    echo ""

    cd "$(dirname "$0")/../fitness_oracle"
    leo execute "$FUNCTION" 160u32 55u32 2000u32 0u8 2026u32 \
        --network "$NETWORK" \
        --endpoint "$ENDPOINT" \
        --private-key "$PRIVATE_KEY" \
        --yes --broadcast 2>&1 | grep -E "Output|bmi|bmr|body_fat|fitness|health|age|transaction ID|confirmed|Fee"
    echo ""
else
    echo -e "${Y}[6] Skipped additional test (no PRIVATE_KEY set)${N}"
fi

# ─── Summary ─────────────────────────────────────────────
echo -e "${C}══════════════════════════════════════════════════════════${N}"
echo -e "${G}  All verifications complete!${N}"
echo -e "${C}══════════════════════════════════════════════════════════${N}"
