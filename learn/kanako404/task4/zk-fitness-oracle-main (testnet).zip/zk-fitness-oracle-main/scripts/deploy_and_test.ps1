# ─────────────────────────────────────────────────────────────
# ZK Fitness Oracle — Testnet Deployment & Interaction (PowerShell)
# ─────────────────────────────────────────────────────────────
#
# Usage:
#   $env:PRIVATE_KEY = "APrivateKey1..."
#   .\scripts\deploy_and_test.ps1
#
# Prerequisites:
#   - Leo CLI 4.x installed
#   - Account funded on Aleo Testnet (https://faucet.aleo.org)

param(
    [string]$PrivateKey = $env:PRIVATE_KEY,
    [string]$Endpoint = "https://api.explorer.provable.com/v1",
    [string]$Network = "testnet"
)

$ErrorActionPreference = "Continue"
$env:PATH = "$env:USERPROFILE\.cargo\bin;$env:PATH"

$ProgramName = "fitness_rpg_6576.aleo"
$FunctionName = "compute_fitness"
$LeoDir = Join-Path $PSScriptRoot "..\fitness_oracle"

# Test inputs
$Height = "175u32"
$Weight = "70u32"
$BirthYear = "1995u32"
$Gender = "1u8"       # 1=male, 0=female
$CurrentYear = "2026u32"

Write-Host ""
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host "   ZK Fitness Oracle - Aleo Testnet Deployment & Interaction" -ForegroundColor Cyan
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host ""

# ─── Step 1: Check prerequisites ──────────────────────────
Write-Host "[1/6] Checking prerequisites..." -ForegroundColor Yellow
try {
    $leoVer = & leo --version 2>&1
    Write-Host "  Leo CLI: $leoVer" -ForegroundColor Green
} catch {
    Write-Host "  Error: Leo CLI not found." -ForegroundColor Red
    exit 1
}

if (-not $PrivateKey) {
    Write-Host "  Error: No private key provided." -ForegroundColor Red
    Write-Host '  Usage: $env:PRIVATE_KEY = "APrivateKey1..."; .\scripts\deploy_and_test.ps1'
    Write-Host "  Get testnet credits: https://faucet.aleo.org"
    exit 1
}
Write-Host "  Private Key: $($PrivateKey.Substring(0,20))..." -ForegroundColor Green
Write-Host "  Endpoint: $Endpoint" -ForegroundColor Green
Write-Host "  Network: $Network" -ForegroundColor Green
Write-Host ""

# ─── Step 2: Compile ──────────────────────────────────────
Write-Host "[2/6] Compiling Leo program..." -ForegroundColor Yellow
Push-Location $LeoDir
$buildOutput = & leo build --network $Network 2>&1
$buildOutput | ForEach-Object { Write-Host "  $_" }
Write-Host ""

# ─── Step 3: Local test run ──────────────────────────────
Write-Host "[3/6] Running local test (no network required)..." -ForegroundColor Yellow
Write-Host "  Input: height=175cm, weight=70kg, birth=1995, gender=male, year=2026"
Write-Host ""
$runOutput = & leo run $FunctionName $Height $Weight $BirthYear $Gender $CurrentYear --network $Network 2>&1
$runOutput | ForEach-Object { Write-Host "  $_" }
Write-Host ""

# ─── Step 4: Deploy ──────────────────────────────────────
Write-Host "[4/6] Deploying $ProgramName to $Network..." -ForegroundColor Yellow
Write-Host "  This may take 2-5 minutes (ZK proof generation)..." -ForegroundColor DarkGray
Write-Host ""
$deployOutput = & leo deploy `
    --network $Network `
    --endpoint $Endpoint `
    --private-key $PrivateKey `
    --yes --broadcast 2>&1
$deployOutput | ForEach-Object { Write-Host "  $_" }

$deployTx = ($deployOutput | Select-String -Pattern 'at1[a-z0-9]+' | Select-Object -First 1)
if ($deployTx) {
    $deployTx = $deployTx.Matches[0].Value
    Write-Host ""
    Write-Host "  Deployment TX: $deployTx" -ForegroundColor Green
    Write-Host "  Explorer: https://testnet.explorer.provable.com/transaction/$deployTx" -ForegroundColor Cyan
} else {
    Write-Host ""
    Write-Host "  Deployment may have failed. Check output above." -ForegroundColor Red
    Write-Host "  Common issues:" -ForegroundColor Yellow
    Write-Host "    - Insufficient balance (need ~3 credits)"
    Write-Host "    - Program name already taken on testnet"
    Write-Host "    - Network congestion / timeout"
}
Write-Host ""

# ─── Step 5: Execute on-chain ────────────────────────────
Write-Host "[5/6] Executing on-chain interaction ($FunctionName)..." -ForegroundColor Yellow
Write-Host "  Input: height=175cm, weight=70kg, birth=1995, gender=male, year=2026"
Write-Host ""
$execOutput = & leo execute $FunctionName `
    $Height $Weight $BirthYear $Gender $CurrentYear `
    --network $Network `
    --endpoint $Endpoint `
    --private-key $PrivateKey `
    --yes --broadcast 2>&1
$execOutput | ForEach-Object { Write-Host "  $_" }

$execTx = ($execOutput | Select-String -Pattern 'at1[a-z0-9]+' | Select-Object -First 1)
if ($execTx) {
    $execTx = $execTx.Matches[0].Value
    Write-Host ""
    Write-Host "  Execution TX: $execTx" -ForegroundColor Green
    Write-Host "  Explorer: https://testnet.explorer.provable.com/transaction/$execTx" -ForegroundColor Cyan
}
Write-Host ""

# ─── Step 6: Print summary ──────────────────────────────
Write-Host "[6/6] Deployment & Interaction Summary" -ForegroundColor Yellow
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host "  Program ID:       $ProgramName" -ForegroundColor White
Write-Host "  Function:         $FunctionName" -ForegroundColor White
Write-Host "  Network:          $Network" -ForegroundColor White
Write-Host "  Endpoint:         $Endpoint" -ForegroundColor White
Write-Host "  Deploy TX:        $($deployTx ?? 'N/A')" -ForegroundColor White
Write-Host "  Execute TX:       $($execTx ?? 'N/A')" -ForegroundColor White
Write-Host "  Program URL:      https://testnet.explorer.provable.com/program/$ProgramName" -ForegroundColor Cyan
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host ""

Pop-Location
