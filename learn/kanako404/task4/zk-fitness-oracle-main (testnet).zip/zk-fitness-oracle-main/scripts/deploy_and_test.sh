#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# ZK Fitness Oracle — Testnet Deployment & Interaction Script
# ─────────────────────────────────────────────────────────────
#
# Usage:
#   chmod +x scripts/deploy_and_test.sh
#   ./scripts/deploy_and_test.sh
#
# Prerequisites:
#   - Leo CLI 4.x installed (cargo install leo-lang)
#   - Account funded on Aleo Testnet (get credits from https://faucet.aleo.org)
#
# Environment variables (or edit below):
#   PRIVATE_KEY  - Your Aleo testnet private key
#   ENDPOINT     - API endpoint (default: https://api.explorer.provable.com/v1)
#   NETWORK      - Network (default: testnet)

set -euo pipefail

# ─── Configuration ─────────────────────────────────────────
PROGRAM_NAME="fitness_rpg_6576.aleo"
FUNCTION_NAME="compute_fitness"
ENDPOINT="${ENDPOINT:-https://api.explorer.provable.com/v1}"
NETWORK="${NETWORK:-testnet}"
PRIVATE_KEY="${PRIVATE_KEY:-}"
LEO_DIR="fitness_oracle"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}   ZK Fitness Oracle — Testnet Deployment & Test${NC}"
echo -e "${CYAN}══════════════════════════════════════════════════════${NC}"
echo ""

# ─── Step 1: Check prerequisites ──────────────────────────
echo -e "${YELLOW}[1/6] Checking prerequisites...${NC}"
if ! command -v leo &> /dev/null; then
    echo -e "${RED}Error: Leo CLI not found. Install with: cargo install leo-lang${NC}"
    exit 1
fi
echo "  Leo CLI: $(leo --version)"

if [ -z "$PRIVATE_KEY" ]; then
    echo -e "${RED}Error: PRIVATE_KEY not set.${NC}"
    echo "  Export your testnet private key:"
    echo "    export PRIVATE_KEY=\"APrivateKey1...\""
    echo "  Get testnet credits: https://faucet.aleo.org"
    exit 1
fi
echo "  Private Key: ${PRIVATE_KEY:0:20}..."
echo "  Endpoint: $ENDPOINT"
echo "  Network: $NETWORK"
echo ""

# ─── Step 2: Compile ──────────────────────────────────────
echo -e "${YELLOW}[2/6] Compiling Leo program...${NC}"
cd "$LEO_DIR"
leo build --network "$NETWORK" 2>&1 | grep -E "Compiled|size|checksum"
echo ""

# ─── Step 3: Local test run ───────────────────────────────
echo -e "${YELLOW}[3/6] Running local test (no network required)...${NC}"
echo "  Input: height=175cm, weight=70kg, birth=1995, gender=male, year=2026"
echo ""
leo run "$FUNCTION_NAME" 175u32 70u32 1995u32 1u8 2026u32 \
    --network "$NETWORK" 2>&1 | grep -A 20 "Output"
echo ""

# ─── Step 4: Deploy to testnet ────────────────────────────
echo -e "${YELLOW}[4/6] Deploying $PROGRAM_NAME to $NETWORK...${NC}"
echo "  This may take 2-5 minutes (ZK proof generation)..."
echo ""
DEPLOY_OUTPUT=$(leo deploy \
    --network "$NETWORK" \
    --endpoint "$ENDPOINT" \
    --private-key "$PRIVATE_KEY" \
    --yes --broadcast 2>&1) || true
echo "$DEPLOY_OUTPUT"

# Extract transaction ID if deployment succeeded
DEPLOY_TX=$(echo "$DEPLOY_OUTPUT" | grep -oP 'at1[a-z0-9]+' | head -1 || echo "")
echo ""

if [ -n "$DEPLOY_TX" ]; then
    echo -e "${GREEN}✅ Deployment successful!${NC}"
    echo -e "  Transaction ID: ${CYAN}$DEPLOY_TX${NC}"
    echo -e "  Explorer: https://testnet.explorer.provable.com/transaction/$DEPLOY_TX"
else
    echo -e "${RED}⚠️  Deployment may have failed. Check output above.${NC}"
    echo "  Common issues:"
    echo "    - Insufficient balance (need ~3 credits)"
    echo "    - Program name already taken"
    echo "    - Network congestion"
fi
echo ""

# ─── Step 5: Execute on-chain ─────────────────────────────
echo -e "${YELLOW}[5/6] Executing on-chain interaction...${NC}"
echo "  Function: $FUNCTION_NAME"
echo "  Input: height=175cm, weight=70kg, birth=1995, gender=male, year=2026"
echo ""
EXEC_OUTPUT=$(leo execute "$FUNCTION_NAME" \
    175u32 70u32 1995u32 1u8 2026u32 \
    --network "$NETWORK" \
    --endpoint "$ENDPOINT" \
    --private-key "$PRIVATE_KEY" \
    --yes --broadcast 2>&1) || true
echo "$EXEC_OUTPUT"

EXEC_TX=$(echo "$EXEC_OUTPUT" | grep -oP 'at1[a-z0-9]+' | head -1 || echo "")
echo ""

if [ -n "$EXEC_TX" ]; then
    echo -e "${GREEN}✅ On-chain execution successful!${NC}"
    echo -e "  Transaction ID: ${CYAN}$EXEC_TX${NC}"
    echo -e "  Explorer: https://testnet.explorer.provable.com/transaction/$EXEC_TX"
else
    echo -e "${RED}⚠️  Execution may have failed. Check output above.${NC}"
fi
echo ""

# ─── Step 6: Print summary ───────────────────────────────
echo -e "${YELLOW}[6/6] Summary${NC}"
echo -e "${CYAN}══════════════════════════════════════════════════════${NC}"
echo -e "  Program:          $PROGRAM_NAME"
echo -e "  Function:         $FUNCTION_NAME"
echo -e "  Network:          $NETWORK"
echo -e "  Endpoint:         $ENDPOINT"
echo -e "  Deploy TX:        ${DEPLOY_TX:-N/A}"
echo -e "  Execute TX:       ${EXEC_TX:-N/A}"
echo -e "  Program URL:      https://testnet.explorer.provable.com/program/$PROGRAM_NAME"
echo -e "${CYAN}══════════════════════════════════════════════════════${NC}"
